<script setup lang="ts">
import { computed, nextTick, onMounted, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { ElMessage } from "element-plus/es/components/message/index";
import { useAuthStore } from "@/stores/auth";
import { useNoticeStore } from "@/stores/notices";

/**
 * 家校沟通独立整页：家长端 ↔ 辅导员端双向对话。
 *
 * 之前这个功能藏在右上角铃铛下拉面板的一个 tab 里，入口太隐蔽，
 * 用户经常找不到——现在提升为左侧棕色导航栏的一级入口，
 * 点进来就是整页的对话界面，比铃铛里那个小窗宽敞得多。
 *
 * - 家长端：只有一个会话（和自家孩子的辅导员），左侧不显示列表
 * - 辅导员端：左侧按学生列出所有家长会话，点谁和谁聊
 * 复用 notices store 的 threads / sendMessage / markThreadRead，不另起一套。
 */
const auth = useAuthStore();
const notices = useNoticeStore();
const route = useRoute();
const router = useRouter();

const role = computed(() => auth.profile?.role || "");
const isParent = computed(() => role.value === "parent");
const isCounselor = computed(() => role.value === "counselor");

// 当前展示的会话（家长端唯一一条；导员端选中的那条）
const currentThread = computed(() => {
  if (isParent.value) return notices.threads[0] || null;
  if (isCounselor.value) {
    return (
      notices.threads.find((t) => t.sid === notices.activeThread) ||
      notices.threads[0] ||
      null
    );
  }
  return null;
});

const draft = ref("");
const bodyRef = ref<HTMLDivElement | null>(null);

function selectThread(sid: string) {
  notices.activeThread = sid;
  const t = notices.threads.find((x) => x.sid === sid);
  if (t && t.unread > 0) void notices.markThreadRead(t.thread_id);
}

async function send() {
  const text = draft.value.trim();
  if (!text || !currentThread.value) return;
  const sid = currentThread.value.sid;
  try {
    await notices.sendMessage(sid, text);
    draft.value = "";
    await nextTick();
    scrollBottom();
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.detail || "发送失败");
  }
}

function scrollBottom() {
  if (bodyRef.value) bodyRef.value.scrollTop = bodyRef.value.scrollHeight;
}

// 进入页面就拉一次消息并标已读
onMounted(async () => {
  await notices.refreshMessages(true);
  await nextTick();
  scrollBottom();
  if (currentThread.value && currentThread.value.unread > 0) {
    void notices.markThreadRead(currentThread.value.thread_id);
  }
});

// 路由 query 里带了 sid 时自动选中（从通知弹窗点进来）
const focusSid = computed(() => (route.query.sid as string) || "");
void focusSid.value;

function backHome() {
  router.push(auth.home());
}
</script>

<template>
  <div class="msg-page">
    <header class="msg-head">
      <div class="msg-head-main">
        <h2>家校沟通</h2>
        <p class="muted">
          <template v-if="isParent">与孩子辅导员的直接对话，消息双方实时可见</template>
          <template v-else>与各学生家长的对话，按学生分组，点左侧切换</template>
        </p>
      </div>
      <button class="btn ghost" @click="backHome">返回工作台</button>
    </header>

    <div v-if="!notices.canMessage" class="msg-empty">
      家校沟通仅家长端和辅导员端可用。
    </div>

    <div v-else class="msg-layout">
      <!-- 导员端：会话列表 -->
      <aside v-if="isCounselor" class="thread-list">
        <div class="thread-list-head">会话列表</div>
        <div v-if="!notices.threads.length" class="thread-empty">
          暂无家校会话。
        </div>
        <button
          v-for="t in notices.threads"
          :key="t.thread_id"
          class="thread-row"
          :class="{ on: t.sid === (currentThread?.sid || '') }"
          @click="selectThread(t.sid)"
        >
          <div class="thread-row-top">
            <b>{{ t.peer_name }}</b>
            <span v-if="t.unread" class="dot">{{ t.unread }}</span>
          </div>
          <span class="thread-ts">{{ t.last_ts || "暂无消息" }}</span>
        </button>
      </aside>

      <!-- 对话区 -->
      <section class="conv">
        <div v-if="!currentThread" class="conv-empty">
          {{ isParent ? "暂无会话，发一条消息给辅导员吧。" : "请在左侧选择一位家长开始对话。" }}
        </div>
        <template v-else>
          <div class="conv-peer">
            正在与 <b>{{ currentThread.peer_name }}</b> 沟通
            <span v-if="currentThread.unread" class="peer-unread">{{ currentThread.unread }} 条未读</span>
          </div>
          <div ref="bodyRef" class="conv-body">
            <div v-if="!currentThread.messages.length" class="conv-hint">
              还没有消息，发一条开启沟通吧。
            </div>
            <div
              v-for="m in currentThread.messages"
              :key="m.id"
              class="bubble"
              :class="{ mine: m.from_role === role }"
            >
              <div class="bubble-head">
                <b>{{ m.from_name }}</b>
                <span class="bubble-ts">{{ m.ts }}</span>
              </div>
              <p class="bubble-text">{{ m.text }}</p>
            </div>
          </div>
          <div class="conv-input">
            <textarea
              v-model="draft"
              rows="3"
              placeholder="输入消息，回车发送（Shift+回车换行）"
              @keydown.enter.exact.prevent="send"
            ></textarea>
            <button class="btn ok" :disabled="notices.sending || !draft.trim()" @click="send">
              {{ notices.sending ? "发送中…" : "发送" }}
            </button>
          </div>
        </template>
      </section>
    </div>
  </div>
</template>

<style scoped>
.msg-page {
  display: flex;
  flex-direction: column;
  gap: 14px;
  min-height: calc(100vh - 120px);
}
.msg-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  padding-bottom: 12px;
  border-bottom: 1px solid var(--line);
}
.msg-head h2 {
  margin: 0;
  font-size: 20px;
  color: var(--text);
}
.msg-head .muted {
  margin: 4px 0 0;
  font-size: 12.5px;
  color: var(--text-2);
}
.btn.ghost {
  border: 1px solid var(--line);
  background: #fff;
  color: var(--text-2);
  padding: 6px 14px;
  border-radius: 8px;
  font-size: 12.5px;
  cursor: pointer;
}
.btn.ghost:hover {
  border-color: var(--brand);
  color: var(--brand);
}

.msg-empty {
  padding: 48px 0;
  text-align: center;
  color: var(--muted);
  font-size: 13px;
}

.msg-layout {
  display: flex;
  gap: 14px;
  flex: 1;
  min-height: 0;
}

/* 导员端会话列表 */
.thread-list {
  flex: none;
  width: 230px;
  border: 1px solid var(--line);
  border-radius: 12px;
  background: #fff;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.thread-list-head {
  padding: 10px 14px;
  font-size: 12px;
  letter-spacing: 1px;
  color: var(--text-2);
  border-bottom: 1px solid var(--line);
  background: var(--brand-soft);
}
.thread-empty {
  padding: 28px 12px;
  text-align: center;
  color: var(--muted);
  font-size: 12.5px;
}
.thread-row {
  border: 0;
  border-bottom: 1px solid var(--line);
  background: transparent;
  text-align: left;
  padding: 11px 14px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  gap: 3px;
  transition: background 0.14s;
}
.thread-row:hover {
  background: var(--brand-soft);
}
.thread-row.on {
  background: var(--brand-soft);
}
.thread-row.on b {
  color: var(--brand);
}
.thread-row-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.thread-row b {
  font-size: 13px;
  color: var(--text);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.thread-ts {
  font-size: 11px;
  color: var(--muted);
}
.dot {
  flex: none;
  min-width: 17px;
  height: 17px;
  padding: 0 5px;
  border-radius: 999px;
  background: #dc2626;
  color: #fff;
  font-size: 10px;
  font-weight: 600;
  display: grid;
  place-items: center;
  line-height: 1;
}

/* 对话区 */
.conv {
  flex: 1;
  min-width: 0;
  border: 1px solid var(--line);
  border-radius: 12px;
  background: #fff;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.conv-empty {
  flex: 1;
  display: grid;
  place-items: center;
  color: var(--muted);
  font-size: 13px;
}
.conv-peer {
  padding: 11px 16px;
  font-size: 13px;
  color: var(--text-2);
  border-bottom: 1px solid var(--line);
  background: var(--brand-soft);
  display: flex;
  align-items: center;
  gap: 10px;
}
.conv-peer b {
  color: var(--text);
}
.peer-unread {
  margin-left: auto;
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 999px;
  background: #dc2626;
  color: #fff;
}
.conv-body {
  flex: 1;
  overflow: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  background: #faf7f2;
}
.conv-hint {
  margin: auto;
  color: var(--muted);
  font-size: 13px;
}
.bubble {
  max-width: 72%;
  padding: 9px 13px;
  border-radius: 12px;
  background: #fff;
  border: 1px solid var(--line);
  font-size: 13px;
  line-height: 1.55;
}
.bubble.mine {
  align-self: flex-end;
  background: var(--brand-soft);
  border-color: var(--brand);
}
.bubble-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 3px;
}
.bubble-head b {
  font-size: 11.5px;
  color: var(--text-2);
  font-weight: 600;
}
.bubble-ts {
  font-size: 10.5px;
  color: var(--muted);
}
.bubble-text {
  margin: 0;
  word-break: break-word;
  color: var(--text);
}
.conv-input {
  display: flex;
  gap: 8px;
  padding: 10px;
  border-top: 1px solid var(--line);
  background: #fff;
}
.conv-input textarea {
  flex: 1;
  resize: none;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 13px;
  font-family: inherit;
  outline: none;
  transition: border-color 0.14s;
}
.conv-input textarea:focus {
  border-color: var(--brand);
}
.btn.ok {
  align-self: stretch;
  border: 0;
  background: var(--brand);
  color: #fff;
  padding: 0 22px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
}
.btn.ok:disabled {
  opacity: 0.5;
  cursor: default;
}

/* 手机端：会话列表收成顶栏横向条 */
@media (max-width: 760px) {
  .msg-layout {
    flex-direction: column;
  }
  .thread-list {
    width: 100%;
    max-height: 140px;
  }
  .thread-row {
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
  }
}
</style>
