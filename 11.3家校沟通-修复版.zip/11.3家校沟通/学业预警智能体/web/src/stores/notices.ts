import { defineStore } from "pinia";
import { computed, ref } from "vue";
import { api } from "@/api/client";
import type { MessageThread, NoticeItem, TodoItem } from "@/types";
import { useAuthStore } from "@/stores/auth";

const POLL_MS = 25_000;

/**
 * 消息中心：各端各自的通知与待办 + 家长端↔辅导员端双向消息。
 * - 登录后立即拉一次，之后每 25 秒轮询；
 * - 有新的未读通知时触发 onArrive 回调（App.vue 用来弹窗）；
 * - 通知/待办按「角色:账号」在后端隔离，前端只管展示与已读。
 * - 家长端和辅导员端额外拉取双向消息（家校沟通）。
 */
export const useNoticeStore = defineStore("notices", () => {
  const auth = useAuthStore();
  const unread = ref<NoticeItem[]>([]);
  const todos = ref<TodoItem[]>([]);
  const panelOpen = ref(false);
  const tab = ref<"notice" | "todo" | "appeals" | "message">("notice");

  // 家校双向消息
  const threads = ref<MessageThread[]>([]);
  const activeThread = ref<string>("");   // 导员端当前选中的会话 sid
  const sending = ref(false);

  let timer: number | null = null;
  let seen = new Set<string>();       // 已经弹过窗的通知 id，避免重复弹
  let lastKey = "";                   // 登录身份变了要重置
  const listeners = new Set<(items: NoticeItem[]) => void>();

  const unreadCount = computed(() => unread.value.length);
  const todoCount = computed(() => todos.value.filter((t) => !t.done).length);
  const messageUnread = computed(() =>
    threads.value.reduce((s, t) => s + t.unread, 0),
  );
  // 家校消息仅家长端和辅导员端可用
  const canMessage = computed(
    () => auth.profile?.role === "parent" || auth.profile?.role === "counselor",
  );

  function onArrive(fn: (items: NoticeItem[]) => void): () => void {
    listeners.add(fn);
    return () => listeners.delete(fn);
  }

  async function refreshMessages(silent = false) {
    if (!canMessage.value) {
      threads.value = [];
      return;
    }
    try {
      const data = await api.messages();
      const prev = threads.value;
      threads.value = data.threads || [];
      // 家长端只有一条线，自动选中
      if (auth.profile?.role === "parent" && threads.value[0]) {
        activeThread.value = threads.value[0].sid;
      }
      // 新消息触发弹窗（对方发来的、未弹过的）
      if (!silent) {
        for (const t of threads.value) {
          const prevT = prev.find((p) => p.thread_id === t.thread_id);
          const prevCnt = prevT ? prevT.messages.length : 0;
          const fresh = t.messages.slice(prevCnt).filter(
            (m) => m.to_role === auth.profile?.role,
          );
          if (fresh.length) {
            for (const m of fresh) {
              // 复用通知弹窗机制：把消息当通知推给 App.vue
              listeners.forEach((fn) =>
                fn([{
                  id: `msg-${m.id}`,
                  kind: "message",
                  title: `${m.from_name} 发来家校消息`,
                  text: m.text,
                  ts: m.ts,
                  read: false,
                  meta: {},
                }]),
              );
            }
          }
        }
      }
    } catch {
      /* 轮询失败静默 */
    }
  }

  async function refresh(silent = false) {
    const profile = auth.profile;
    if (!profile) return;
    const key = `${profile.role}:${profile.account}`;
    if (key !== lastKey) {
      lastKey = key;
      seen = new Set();               // 换了身份，弹窗历史清零
      threads.value = [];
      activeThread.value = "";
    }
    try {
      const data = await api.notifications();
      const fresh = (data.unread || []).filter((n) => !seen.has(n.id));
      unread.value = data.unread || [];
      todos.value = data.todos || [];
      if (fresh.length && !silent) {
        fresh.forEach((n) => seen.add(n.id));
        listeners.forEach((fn) => fn(fresh));
      }
    } catch {
      /* 轮询失败静默，下轮再试 */
    }
    // 家长/导员顺便拉消息
    void refreshMessages(silent);
  }

  function start() {
    stop();
    void refresh();
    timer = window.setInterval(() => void refresh(), POLL_MS);
  }

  function stop() {
    if (timer !== null) {
      clearInterval(timer);
      timer = null;
    }
  }

  async function markRead(ids: string[]) {
    if (!ids.length) return;
    try {
      await api.markNoticesRead(ids);
      unread.value = unread.value.filter((n) => !ids.includes(n.id));
    } catch {
      /* 忽略 */
    }
  }

  async function finishTodo(id: string) {
    const row = todos.value.find((t) => t.id === id);
    if (!row || row.done) return;
    row.done = true;                    // 乐观更新，失败再回滚
    try {
      await api.finishTodo(id);
    } catch {
      row.done = false;
    }
  }

  async function sendMessage(sid: string, text: string) {
    if (!text.trim()) return;
    sending.value = true;
    try {
      await api.sendMessage(sid, text);
      await refreshMessages(true);
    } finally {
      sending.value = false;
    }
  }

  async function markThreadRead(threadId: string) {
    try {
      await api.markMessagesRead(threadId);
      const t = threads.value.find((x) => x.thread_id === threadId);
      if (t) t.unread = 0;
    } catch {
      /* 忽略 */
    }
  }

  function openPanel(which: "notice" | "todo" | "appeals" | "message" = "notice") {
    tab.value = which;
    panelOpen.value = true;
    if (which === "message") void refreshMessages(true);
  }

  return {
    unread, todos, unreadCount, todoCount,
    panelOpen, tab,
    threads, activeThread, messageUnread, canMessage, sending,
    refresh, start, stop, markRead, finishTodo, onArrive, openPanel,
    sendMessage, markThreadRead, refreshMessages,
  };
});
