import type { Role } from "@/types";
import { MODULES, type NavItem } from "@/config/modules";

/**
 * 门户首屏的图形配置。
 *
 * 三条规则：
 * 1. **清单有几条，画布上就有几个节点**——节点由 `MODULES` 生成，不多不少。
 * 2. **入口数量决定节点形状**，边数随数量增加而增加，越多越接近圆：
 *    3~4 菱形 / 5 五边形 / 6 六边形 / 7~8 八边形 / 9 以上十边形。
 *    全部都是多边形——混一个纯圆进来会和另外四端不是同一套语言。
 * 3. **坐标是手写死的，不是算出来的**——网格算法一定会排出「齐整」的观感，
 *    所以每一端的节点位置都按构图单独摆：间距不等、上下不相齐、允许某一端
 *    整体偏左或偏右。换数量时只改这张表，排布逻辑不参与。
 */
export type NodeShape = "diamond" | "pent" | "hex" | "oct" | "dec";

export interface PortalNode {
  key: string;
  no: string;
  label: string;
  en: string;
  /** 画布坐标，百分比 */
  x: number;
  y: number;
  /** 只转形状层，文字层保持水平——像手贴便签的轻微歪斜 */
  rot?: number;
  /** 单个节点的缩放，0.94~1.05 之间来回，避免整齐划一 */
  scale?: number;
  /** 目标路由：点节点直接去这一页 */
  to?: string;
  /** 唤起 AI 对话抽屉 */
  act?: "ai";
  /** 需要显示未读数的节点 */
  badge?: "checkin" | "messages";
  tone?: "risk" | "learn" | "ai";
  note?: string;
}

export interface PortalMeta {
  kicker: string;
  /** 描边那一行 */
  outline: string;
  /** 实心那一行 */
  solid: string;
  /** 画布左上角的小字 */
  mark: string;
  /** 画布右下角的小字 */
  trace: string;
  /** 左侧大标题的前半句（数字由节点数量填进去） */
  lead: string;
  /** 大标题的后半句 */
  tail: string;
  /** 标题下面那段说明 */
  sub: string;
  /** 焦点卡左上角的方括号标签，如「本院」「本校」 */
  focusTag: string;
}

/** 入口数量 → 形状 */
export function shapeOf(count: number): NodeShape {
  if (count <= 4) return "diamond";
  if (count === 5) return "pent";
  if (count === 6) return "hex";
  if (count <= 8) return "oct";
  return "dec";
}

/** 形状的边数 */
export function sidesOf(shape: NodeShape): number {
  if (shape === "diamond") return 4;
  if (shape === "pent") return 5;
  if (shape === "hex") return 6;
  if (shape === "oct") return 8;
  return 10;
}

/** 正多边形顶点，从正上方开始顺时针；圆心 50,50 */
export function polygonPoints(sides: number, r = 47): string {
  const out: string[] = [];
  for (let i = 0; i < sides; i++) {
    const a = ((-90 + (i * 360) / sides) * Math.PI) / 180;
    out.push(`${(50 + r * Math.cos(a)).toFixed(2)},${(50 + r * Math.sin(a)).toFixed(2)}`);
  }
  return out.join(" ");
}

/** 形状直径：入口越多缩得越小，保证 11 个节点也不打架 */
export function sizeOf(count: number): number {
  if (count <= 4) return 94;
  if (count <= 6) return 78;
  if (count <= 8) return 70;
  return 64;
}

/* ==========================================================================
   手写坐标表
   --------------------------------------------------------------------------
   画布是 100×100 的百分比坐标系。约定：
   · x 留 5~95，y 留 18~74（上方是标题行、下方是 AI 输入条）
   · 相邻节点横向至少隔 13、纵向至少隔 13（节点块约 10×21，这个距离不打架）
   · 编号顺序就是点的顺序，主链顺着编号连，所以表的顺序决定了线怎么走
   ========================================================================== */
const LAYOUT: Record<Role, [number, number][]> = {
  // 11 个：四段折返。上排往右、右端斜下、中排往左、左下再折回右下
  student: [
    [9.5, 30],
    [23.5, 21],
    [37.5, 31],
    [51.5, 22.5],
    [69, 33],
    [86, 45],
    [69, 58],
    [53, 49],
    [36, 59],
    [21, 69],
    [47, 77],
  ],
  // 4 个：一个 Z 字，靠疏密和转角撑住画面，不摆成四角方框
  counselor: [
    [12, 28],
    [34, 68],
    [60, 24],
    [87, 60],
  ],
  // 5 个：一道不对称的谷形弧，最低点偏左，右端抬得最高
  admin: [
    [10, 31],
    [28, 58],
    [49, 72],
    [73, 47],
    [90, 25],
  ],
  // 3 个：倒 V，中间那个顶到最高，两边不齐高
  teacher: [
    [16, 70],
    [50, 25],
    [83, 62],
  ],
  // 3 个：一个三角，左上角起、右上角折回、底部收在中偏左
  parent: [
    [16, 28],
    [84, 42],
    [45, 76],
  ],
};

/** 每端节点的歪斜角度，手挑的不规则序列，不用取模循环 */
const ROT: Record<Role, number[]> = {
  student: [7, -5, 9, -8, 4, -11, 6, -3, 10, -6, 5],
  counselor: [-6, 8, -9, 5],
  admin: [8, -7, 4, -10, 6],
  teacher: [-8, 9, -5],
  parent: [7, -9, 4],
};

/** 单个节点的缩放微差，让形状不完全一样大 */
const SCL: number[] = [1, 0.95, 1.03, 0.97, 1.02, 0.94, 1.04, 0.98, 1.01, 0.96, 1.03];

/** 少数节点换一种笔触：AI 用陶土赭虚线，风险/成长类压深一档 */
const TONE: Record<string, PortalNode["tone"]> = {
  chat: "ai",
  roster: "risk",
  forest: "learn",
  tree: "learn",
};

/** 表里没有这一端（或数量对不上）时的兜底：沿一道浅弧均匀铺开 */
function spread(n: number): [number, number][] {
  const out: [number, number][] = [];
  for (let i = 0; i < n; i++) {
    const t = n === 1 ? 0.5 : i / (n - 1);
    out.push([10 + t * 80, 46 - Math.sin(t * Math.PI) * 20 + (i % 2 ? 6 : -6)]);
  }
  return out;
}

/** 把一端的所有条目摊平成画布节点：编号、坐标、动作都在这里定下来 */
export function buildNodes(role: Role): PortalNode[] {
  const items: NavItem[] = (MODULES[role] ?? MODULES.student).flatMap((g) => g.items);
  const base = LAYOUT[role];
  const pos = base && base.length === items.length ? base : spread(items.length);

  return items.map((it, i) => ({
    key: it.key,
    no: String(i + 1).padStart(2, "0"),
    label: it.label,
    en: it.en,
    x: pos[i][0],
    y: pos[i][1],
    rot: ROT[role]?.[i] ?? 0,
    scale: SCL[i % SCL.length],
    to: it.to,
    act: it.chat ? "ai" : undefined,
    badge: it.badge,
    tone: TONE[it.key],
    note: it.hint,
  }));
}

export const PORTAL: Record<Role, PortalMeta> = {
  student: {
    kicker: "STUDENT PORTAL / 我的学习空间",
    outline: "学业",
    solid: "画像",
    mark: "PIPELINE / LEARN",
    trace: "COURSE → CHECKIN → TRACK → TREE",
    lead: "这学期，你还有",
    tail: "件事能做",
    sub: "按紧急程度从左往右排，点开任意一个就能处理。数据每周更新一次，不用自己算。",
    focusTag: "本院",
  },
  counselor: {
    kicker: "COUNSELOR PORTAL / 班级研判台",
    outline: "一个班",
    solid: "四件事",
    mark: "PIPELINE / RISK",
    trace: "SIS → EXAM → CLEAN → SCORE → NOTIFY",
    lead: "这个班，",
    tail: "件事等你拍板",
    sub: "名单、谈话、台账都在这一张图上。点哪个进去就是哪件事，不用先翻菜单找。",
    focusTag: "本班",
  },
  admin: {
    kicker: "ACADEMIC OFFICE / 全校总控台",
    outline: "全校",
    solid: "总控台",
    mark: "PIPELINE / GOVERN",
    trace: "RULE → RECALC → RANK → EXPORT",
    lead: "这一周，",
    tail: "个口子要看",
    sub: "规则、总览、账号、课程都收在这张总控图上，改完立刻落到各端，不用逐级通知。",
    focusTag: "本校",
  },
  teacher: {
    kicker: "FACULTY PORTAL / 课堂观察窗",
    outline: "课堂",
    solid: "观察窗",
    mark: "PIPELINE / CLASS",
    trace: "ATTEND → HOMEWORK → SCORE → ADVISE",
    lead: "你的课，",
    tail: "件事值得先看",
    sub: "考勤、作业、成绩、建议按课堂顺序铺开，点一个就进到对应那节课的数据里。",
    focusTag: "我的课",
  },
  parent: {
    kicker: "FAMILY PORTAL / 孩子这一学期",
    outline: "孩子",
    solid: "这学期",
    mark: "PIPELINE / FAMILY",
    trace: "SCORE → RISK → CARE → LETTER",
    lead: "孩子这学期，",
    tail: "件事和你有关",
    sub: "成绩、状态、和老师的沟通都在这里。点开任何一个，都能看到不带术语的说明。",
    focusTag: "我家",
  },
};
