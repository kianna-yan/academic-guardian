<script setup lang="ts">
import { computed, onMounted, ref, watch } from "vue";
import { useRouter } from "vue-router";
import {
  PORTAL,
  buildNodes,
  polygonPoints,
  shapeOf,
  sidesOf,
  sizeOf,
  type PortalNode,
} from "@/config/portal";
import { api } from "@/api/client";
import { useChatStore } from "@/stores/chat";
import { useNoticeStore } from "@/stores/notices";
import type { PortalSummary, Role } from "@/types";

/**
 * 端口首屏：左边说话，右边是图。
 *
 * 左侧一栏负责「现在是什么状况」——一句大字标题、一段人话说明、三个数字、
 * 一张最该先做的事；右侧是一张图纸式画布，清单里有几个入口就画几个节点。
 * 点节点直接路由跳过去，看板内容不点不出现。
 */
const props = defineProps<{ role: Role; sid: string | null }>();

const router = useRouter();
const chat = useChatStore();
const notices = useNoticeStore();

const meta = computed(() => PORTAL[props.role] ?? PORTAL.student);
const nodes = computed(() => buildNodes(props.role));
const shape = computed(() => shapeOf(nodes.value.length));
const size = computed(() => sizeOf(nodes.value.length));

/* ---------------- 左侧：统计与焦点 ---------------- */
const summary = ref<PortalSummary | null>(null);

async function loadSummary() {
  try {
    summary.value = await api.portalSummary();
  } catch {
    summary.value = null; // 取不到就把数字收掉，标题和节点照常显示
  }
}
onMounted(loadSummary);
watch(() => props.role, loadSummary);

/** 后端没返回时兜个底：入口数 + 未完成待办，至少不是空白 */
const stats = computed(() => {
  const rows = summary.value?.stats ?? [];
  if (rows.length) return rows;
  return [
    { label: "个入口", value: nodes.value.length },
    { label: "项待办", value: notices.todoCount },
  ];
});

const focus = computed(() => summary.value?.focus ?? []);
const focusTitle = computed(() => summary.value?.focus_title || "优先处理");

const AI_HINT: Record<Role, string> = {
  student: "问点什么：我的风险分为什么这么高？",
  counselor: "比如：本班谁的风险上升最快？",
  admin: "比如：全校风险分布如何？",
  parent: "比如：孩子这学期情况怎么样？",
  teacher: "比如：我课上谁最需要关注？",
};
const aiHint = computed(() => AI_HINT[props.role] ?? AI_HINT.student);

/* ------------------------------------------------------------------
 * 拓扑：主链按编号顺序连，旁支另外挑两对，再撒几条不连接任何节点的
 * 悬空弧线。曲线用一个二次贝塞尔，控制点沿法线偏一点，于是主链会
 * 自然折返，不会摆成环或网格。
 * ---------------------------------------------------------------- */
function curve(a: PortalNode, b: PortalNode, bend: number): string {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const k = len * bend;
  const mx = (a.x + b.x) / 2 + nx * k;
  const my = (a.y + b.y) / 2 + ny * k;
  return `M${a.x.toFixed(2)} ${a.y.toFixed(2)} Q${mx.toFixed(2)} ${my.toFixed(2)} ${b.x.toFixed(2)} ${b.y.toFixed(2)}`;
}

const chain = computed(() => {
  const out: { d: string; i: number }[] = [];
  // 每段弯曲的方向和幅度都不一样，手挑的一串，看得出是画的而不是算的
  const bends = [0.14, -0.19, 0.21, -0.13, 0.16, -0.22, 0.11, -0.17, 0.2, -0.15];
  for (let i = 0; i < nodes.value.length - 1; i++) {
    const a = nodes.value[i];
    const b = nodes.value[i + 1];
    out.push({ d: curve(a, b, bends[i % bends.length]), i });
  }
  return out;
});

/** 旁支：跳过中间节点连一条软虚线，制造不对称的网络感 */
const branches = computed(() => {
  const n = nodes.value;
  // 只有 3 个节点时主链是条断头路，补一条回头的弧，让它收成一个三角
  if (n.length === 3) return [{ d: curve(n[2], n[0], -0.24), i: 0 }];
  if (n.length < 5) return [];
  const pairs: [number, number][] = [
    [0, Math.min(3, n.length - 1)],
    [Math.max(0, n.length - 4), n.length - 1],
  ];
  if (n.length >= 9) pairs.push([1, Math.min(7, n.length - 1)]);
  return pairs
    .filter(([a, b]) => b - a > 1)
    .map(([a, b], i) => ({ d: curve(n[a], n[b], i % 2 ? -0.3 : 0.3), i }));
});

/** 悬空铅笔弧：纯装饰，不连任何节点 */
const arcs = computed(() => [
  { d: "M3.5 44 Q11 37 20 45", i: 0 },
  { d: "M50 86 Q60 80 68 85", i: 1 },
  { d: "M46 11 Q56 6 65 12", i: 2 },
]);

/* ------------------------------------------------------------------
 * 星空：用角色名做种子的确定性伪随机，刷新不会跳动
 *
 * 一批细碎的点，加几颗带十字尖角的亮星。位置写死在 0~100 的百分比里，
 * 用普通定位元素而不是 SVG 圆——画布是拉伸的 viewBox，圆放进去会变成椭圆。
 * ---------------------------------------------------------------- */
interface Star {
  x: number;
  y: number;
  s: number;
  o: number;
  d: number;
  big: boolean;
}
const stars = computed<Star[]>(() => {
  let seed = 2166136261;
  for (const ch of `${props.role}-star`) {
    seed = (seed ^ ch.charCodeAt(0)) >>> 0;
    seed = Math.imul(seed, 16777619) >>> 0;
  }
  const rnd = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  const out: Star[] = [];
  for (let i = 0; i < 74; i++) {
    out.push({
      x: 2 + rnd() * 96,
      y: 3 + rnd() * 94,
      s: 2.2 + rnd() * 2.8,
      o: 0.3 + rnd() * 0.45,
      d: rnd() * 6,
      big: false,
    });
  }
  for (let i = 0; i < 9; i++) {
    out.push({
      x: 5 + rnd() * 90,
      y: 8 + rnd() * 82,
      s: 8 + rnd() * 6,
      o: 0.35 + rnd() * 0.35,
      d: rnd() * 5,
      big: true,
    });
  }
  return out;
});

const sides = computed(() => sidesOf(shape.value));
const polygon = computed(() => (sides.value ? polygonPoints(sides.value) : null));

function badgeOf(n: PortalNode): number {
  if (n.badge !== "messages") return 0;
  return notices.messageUnread;
}

function openAi() {
  chat.openAi();
}

/** 点节点只有一个动作：进那一页（AI 那条是展开对话抽屉） */
function go(n: PortalNode) {
  if (n.act === "ai") {
    openAi();
    return;
  }
  if (!n.to) return;
  void router.push(n.to);
}

/** 左侧焦点行：直接问 AI 一句，省得自己组织语言 */
function askFocus(title: string) {
  if (!title) return;
  chat.ask(props.role, props.sid, title);
}
</script>

<template>
  <section
    class="portal"
    :class="[`pt-${role}`, `sh-${shape}`]"
    :style="{ '--nd': `${size}px` }"
    data-test="portal"
  >
    <!-- 图纸网格：9px 细线 + 45px 粗线，压到几乎看不见，只提供纸面质感 -->
    <div class="pt-grid" aria-hidden="true"></div>

    <!-- 星空：细碎的点 + 几颗四角亮星，慢慢明灭 -->
    <div class="pt-stars" aria-hidden="true">
      <i
        v-for="(s, i) in stars"
        :key="`s-${i}`"
        class="star"
        :class="{ big: s.big }"
        :style="{
          left: `${s.x}%`,
          top: `${s.y}%`,
          width: `${s.s}px`,
          height: `${s.s}px`,
          opacity: s.o,
          animationDelay: `${s.d}s`,
        }"
      ></i>
    </div>

    <!-- 四角的裁切角标：像一张印好的图纸，不是网页画布 -->
    <div class="pt-crop" aria-hidden="true">
      <i></i><i></i><i></i><i></i>
    </div>

    <!-- ============ 左栏：一句话说清现状 ============ -->
    <aside class="pt-side">
      <p class="pt-kicker">{{ meta.kicker }}</p>
      <p class="pt-mark">{{ meta.mark }} · MODULE {{ String(nodes.length).padStart(2, "0") }} / SOURCE 3</p>

      <h1 class="pt-hero">
        <span class="hero-lead">{{ meta.lead }}</span>
        <span class="hero-line"><em>{{ nodes.length }}</em>{{ meta.tail }}</span>
      </h1>

      <p class="pt-sub">{{ meta.sub }}</p>

      <p class="pt-stats">
        <template v-for="(s, i) in stats" :key="s.label">
          <i v-if="i" class="st-sep" aria-hidden="true">·</i>
          <span class="st"><b>{{ s.value }}</b>{{ s.label }}</span>
        </template>
      </p>

      <div v-if="focus.length" class="pt-focus">
        <div class="fx-head">
          <span class="fx-tag">{{ meta.focusTag }}</span>
          <b>{{ focusTitle }}</b>
          <button class="fx-ask" title="问问 AI 该怎么办" @click="askFocus(focus[0].title)">
            问 AI
          </button>
        </div>
        <button
          v-for="f in focus"
          :key="f.title + f.meta"
          class="fx-row"
          @click="askFocus(f.title)"
        >
          <span class="fx-k">{{ f.tag }}</span>
          <span class="fx-body">
            <b>{{ f.title }}</b>
            <i v-if="f.meta">{{ f.meta }}</i>
          </span>
        </button>
      </div>
    </aside>

    <!-- ============ 右栏：画布 ============ -->
    <div class="pt-canvas">
      <!-- 描边大字叠实心大字：整块做水印，节点从它上面流过去 -->
      <div class="pt-ghost" aria-hidden="true">
        <span class="g-out">{{ meta.outline }}</span>
        <span class="g-fill">{{ meta.solid }}</span>
      </div>

      <div class="pt-legend">
        <span class="lg"><i class="lg-shape"></i>入口</span>
        <span class="lg"><i class="lg-line"></i>主链</span>
        <span class="lg"><i class="lg-dash"></i>旁支</span>
      </div>

      <!-- 连线层与节点层共用同一套百分比坐标，缩放时始终对齐 -->
      <svg class="pt-edges" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <path
          v-for="c in arcs"
          :key="`arc-${c.i}`"
          :d="c.d"
          class="edge-arc"
          vector-effect="non-scaling-stroke"
        />
        <path
          v-for="b in branches"
          :key="`br-${b.i}`"
          :d="b.d"
          class="edge-branch"
          vector-effect="non-scaling-stroke"
        />
        <path
          v-for="c in chain"
          :key="`ch-${c.i}`"
          :d="c.d"
          class="edge-chain"
          vector-effect="non-scaling-stroke"
        />
      </svg>

      <div class="pt-field">
        <button
          v-for="n in nodes"
          :key="n.key"
          class="pt-node"
          :class="[n.tone ? `tn-${n.tone}` : '', { on: n.act === 'ai' }]"
          :style="{ left: `${n.x}%`, top: `${n.y}%` }"
          :title="n.note"
          :data-node="n.key"
          @click="go(n)"
        >
          <span
            class="nd-shape"
            :style="{ '--tilt': `${n.rot || 0}deg`, '--s': n.scale || 1 }"
          >
            <svg viewBox="0 0 100 100" aria-hidden="true">
              <polygon :points="polygon" />
            </svg>
            <span class="nd-no">{{ n.no }}</span>
            <span v-if="badgeOf(n)" class="nd-badge">{{ badgeOf(n) > 99 ? "99+" : badgeOf(n) }}</span>
          </span>
          <span class="nd-label">{{ n.label }}</span>
          <span class="nd-en">{{ n.en }}</span>
        </button>
      </div>

      <div class="pt-marks" aria-hidden="true">
        <span class="mk mk-bl"><i class="mk-dot"></i> ONLINE</span>
        <span class="mk mk-br">{{ meta.trace }}</span>
      </div>
    </div>

    <!-- AI 常驻在端口最下方：点一下向上展开铺满界面，收起后原样退回 -->
    <div class="pt-dock">
      <button class="ai-dock" data-test="ai-dock" @click="openAi">
        <span class="dk-ava">AI</span>
        <span class="dk-ph">{{ aiHint }}</span>
        <span class="dk-go">
          展开
          <svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true">
            <path
              d="M6 14.5 12 8.5l6 6"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </span>
      </button>
    </div>

  </section>
</template>

<style scoped>
/* ==========================================================================
   端口首屏 · 左栏说话，右栏画图
   纸底 + 细网格 + 星空 + 描边大字 + 曲线节点，配色一支墨绿、一支陶土赭
   ========================================================================== */
.portal {
  --moss: #16564a;
  --clay: #b4552d;
  --ink: #23261f;
  --ink-3: #7c8175;
  --paper-2: #efeae0;
  position: relative;
  display: grid;
  grid-template-columns: minmax(292px, 31%) minmax(0, 1fr);
  grid-template-rows: minmax(0, 1fr) auto;
  height: clamp(560px, calc(100vh - 132px), 900px);
  margin: 0 0 22px;
  padding: 0;
  border: 1px solid var(--line);
  border-radius: 16px;
  background:
    radial-gradient(120% 90% at 8% 4%, #fbf9f3 0%, rgba(251, 249, 243, 0) 58%),
    var(--paper-2);
  overflow: hidden;
  isolation: isolate;
}

/* 9px 细线 + 45px 粗线，压到几乎看不见，只提供纸面质感 */
.pt-grid {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  background-image:
    linear-gradient(to right, rgba(35, 38, 31, 0.04) 1px, transparent 1px),
    linear-gradient(to bottom, rgba(35, 38, 31, 0.04) 1px, transparent 1px),
    linear-gradient(to right, rgba(35, 38, 31, 0.07) 1px, transparent 1px),
    linear-gradient(to bottom, rgba(35, 38, 31, 0.07) 1px, transparent 1px);
  background-size: 9px 9px, 9px 9px, 45px 45px, 45px 45px;
  -webkit-mask-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.95), rgba(0, 0, 0, 0.55));
  mask-image: linear-gradient(to bottom, rgba(0, 0, 0, 0.95), rgba(0, 0, 0, 0.55));
}

/* ---------- 星空 ---------- */
.pt-stars {
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  overflow: hidden;
}
.star {
  position: absolute;
  border-radius: 50%;
  background: #16564a;
  transform: translate(-50%, -50%);
  box-shadow: 0 0 4px rgba(22, 86, 74, 0.35);
  animation: twinkle 5.2s ease-in-out infinite;
}
/* 每三颗换一颗暖色，纸面上才不是一色的小点 */
.star:nth-child(3n) {
  background: #b4552d;
  box-shadow: 0 0 5px rgba(180, 85, 45, 0.32);
}
/* 四角星：十字尖角用 clip-path 切，不用图片 */
.star.big {
  border-radius: 0;
  background: linear-gradient(180deg, #b4552d, #a9681f);
  box-shadow: none;
  clip-path: polygon(
    50% 0%,
    58% 42%,
    100% 50%,
    58% 58%,
    50% 100%,
    42% 58%,
    0% 50%,
    42% 42%
  );
  animation-duration: 6.4s;
}
@keyframes twinkle {
  0%,
  100% {
    opacity: 0.18;
    transform: translate(-50%, -50%) scale(0.82);
  }
  50% {
    opacity: 0.72;
    transform: translate(-50%, -50%) scale(1.05);
  }
}

/* ---------- 图纸角标 ---------- */
.pt-marks {
  position: absolute;
  inset: 0;
  z-index: 2;
  pointer-events: none;
  font-size: 8.5px;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: rgba(35, 38, 31, 0.4);
}
.mk {
  position: absolute;
  bottom: 14px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  white-space: nowrap;
}
.mk-bl {
  left: 18px;
}
.mk-br {
  right: 18px;
}
.mk-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--moss);
  box-shadow: 0 0 0 3px rgba(22, 86, 74, 0.12);
}

/* 四角裁切标：两条短线拼一个 L，压在纸面四角 */
.pt-crop {
  position: absolute;
  inset: 9px;
  z-index: 4;
  pointer-events: none;
}
.pt-crop i {
  position: absolute;
  width: 11px;
  height: 11px;
  border: 0 solid rgba(35, 38, 31, 0.26);
}
.pt-crop i:nth-child(1) {
  top: 0;
  left: 0;
  border-top-width: 1px;
  border-left-width: 1px;
}
.pt-crop i:nth-child(2) {
  top: 0;
  right: 0;
  border-top-width: 1px;
  border-right-width: 1px;
}
.pt-crop i:nth-child(3) {
  bottom: 0;
  left: 0;
  border-bottom-width: 1px;
  border-left-width: 1px;
}
.pt-crop i:nth-child(4) {
  bottom: 0;
  right: 0;
  border-bottom-width: 1px;
  border-right-width: 1px;
}

/* ==========================================================================
   左栏
   ========================================================================== */
.pt-side {
  grid-area: 1 / 1 / 2 / 2;
  position: relative;
  z-index: 4;
  display: flex;
  flex-direction: column;
  padding: 34px 26px 18px 38px;
  min-width: 0;
}
.pt-kicker {
  margin: 0;
  font-size: 10.5px;
  letter-spacing: 0.16em;
  color: var(--moss);
  text-transform: uppercase;
  font-weight: 600;
}
.pt-mark {
  margin: 5px 0 0;
  font-size: 8.5px;
  letter-spacing: 0.2em;
  color: rgba(35, 38, 31, 0.42);
  text-transform: uppercase;
}
.pt-hero {
  margin: 26px 0 0;
  font-family: var(--serif);
  font-weight: 600;
  font-size: clamp(27px, 2.5vw, 38px);
  line-height: 1.32;
  letter-spacing: 0.01em;
  color: var(--ink);
}
.hero-lead {
  display: block;
}
.hero-line {
  display: block;
  margin-top: 2px;
}
.pt-hero em {
  font-style: normal;
  margin-right: 4px;
  font-size: 1.24em;
  color: var(--clay);
}
.pt-sub {
  margin: 16px 0 0;
  max-width: 30ch;
  font-size: 12.5px;
  line-height: 1.9;
  color: var(--ink-3);
}
.pt-stats {
  margin: 18px 0 0;
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 6px;
  font-size: 11.5px;
  color: var(--ink-3);
}
.pt-stats .st {
  display: inline-flex;
  align-items: baseline;
  gap: 3px;
}
.pt-stats b {
  font-family: var(--serif);
  font-size: 16px;
  font-weight: 700;
  color: var(--moss);
  font-variant-numeric: tabular-nums;
}
.st-sep {
  font-style: normal;
  color: rgba(35, 38, 31, 0.3);
  padding: 0 2px;
}

/* 焦点卡：三件最该先做的事，点一行就问 AI */
.pt-focus {
  margin-top: auto;
  padding: 12px 12px 8px;
  border: 1px solid var(--line);
  border-radius: 12px;
  background: color-mix(in srgb, #fffdf9 88%, transparent);
  box-shadow: 0 6px 18px rgba(35, 38, 31, 0.05);
}
.fx-head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding-bottom: 8px;
  border-bottom: 1px dashed rgba(35, 38, 31, 0.14);
}
.fx-tag {
  flex: none;
  padding: 2px 7px;
  border-radius: 4px;
  background: var(--clay-soft, #f7e7dd);
  color: var(--clay);
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.04em;
}
.fx-head b {
  flex: 1;
  min-width: 0;
  font-size: 12px;
  font-weight: 600;
  color: var(--ink);
}
.fx-ask {
  flex: none;
  border: 0;
  background: transparent;
  color: var(--moss);
  font-size: 10.5px;
  font-weight: 600;
  cursor: pointer;
  padding: 0;
}
.fx-ask:hover {
  text-decoration: underline;
}
.fx-row {
  width: 100%;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 2px;
  border: 0;
  border-bottom: 1px solid rgba(35, 38, 31, 0.07);
  background: none;
  text-align: left;
  cursor: pointer;
}
.fx-row:last-child {
  border-bottom: 0;
}
.fx-row:hover .fx-body b {
  color: var(--moss);
}
.fx-k {
  flex: none;
  margin-top: 1px;
  padding: 1px 6px;
  border: 1px solid rgba(22, 86, 74, 0.22);
  border-radius: 3px;
  font-size: 9.5px;
  color: var(--moss);
  line-height: 1.5;
}
.fx-body {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.fx-body b {
  font-size: 12px;
  font-weight: 600;
  color: var(--ink);
  line-height: 1.5;
  transition: color 0.15s;
}
.fx-body i {
  font-style: normal;
  font-size: 10.5px;
  line-height: 1.55;
  color: var(--ink-3);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* ==========================================================================
   右栏画布
   ========================================================================== */
.pt-canvas {
  grid-area: 1 / 2 / 2 / 3;
  position: relative;
  min-width: 0;
  overflow: hidden;
}

/* 描边大字压着实心大字：整块做水印，节点从上面流过去 */
.pt-ghost {
  position: absolute;
  inset: 0;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding-left: 6%;
  pointer-events: none;
  user-select: none;
}
.pt-ghost span {
  font-family: var(--serif);
  font-weight: 600;
  font-size: clamp(46px, 6.4vw, 88px);
  line-height: 1.02;
  letter-spacing: 0.05em;
}
.g-out {
  color: transparent;
  -webkit-text-stroke: 1.2px rgba(22, 86, 74, 0.2);
}
.g-fill {
  margin-top: -0.15em;
  margin-left: 0.1em;
  color: rgba(22, 86, 74, 0.05);
}

.pt-legend {
  position: absolute;
  top: 18px;
  right: 22px;
  z-index: 3;
  display: flex;
  align-items: center;
  gap: 14px;
  font-size: 9.5px;
  letter-spacing: 0.06em;
  color: var(--ink-3);
}
.lg {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.lg-shape {
  width: 8px;
  height: 8px;
  border: 1.4px solid var(--moss);
  border-radius: 1px;
  background: #fffdf9;
}
.lg-line {
  width: 16px;
  height: 0;
  border-top: 1.4px solid rgba(22, 86, 74, 0.55);
}
.lg-dash {
  width: 16px;
  height: 0;
  border-top: 1.4px dashed rgba(35, 38, 31, 0.35);
}

/* ---------- 连线层 ---------- */
.pt-edges {
  position: absolute;
  inset: 0;
  z-index: 2;
  width: 100%;
  height: 100%;
  pointer-events: none;
  overflow: visible;
}
.edge-chain {
  fill: none;
  stroke: rgba(22, 86, 74, 0.5);
  stroke-width: 1.5;
}
.edge-branch {
  fill: none;
  stroke: rgba(35, 38, 31, 0.22);
  stroke-width: 1;
  stroke-dasharray: 3 5;
}
.edge-arc {
  fill: none;
  stroke: rgba(35, 38, 31, 0.17);
  stroke-width: 0.9;
}

/* 节点层：桌面端铺满画布，窄屏改成一个两列网格 */
.pt-field {
  position: absolute;
  inset: 0;
  z-index: 3;
}

/* ---------- 节点 ---------- */
.pt-node {
  position: absolute;
  z-index: 3;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  width: calc(var(--nd, 76px) * 1.62);
  padding: 0;
  border: 0;
  background: none;
  transition: transform 0.18s ease;
}
.pt-node:hover,
.pt-node:focus-visible {
  transform: translate(-50%, -50%) translateY(-2px);
  outline: none;
}
.nd-shape {
  position: relative;
  width: var(--nd, 76px);
  height: var(--nd, 76px);
  display: grid;
  place-items: center;
  transform: rotate(var(--tilt, 0deg)) scale(var(--s, 1));
  transition: transform 0.18s ease;
}
.nd-shape svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
}
.nd-shape polygon {
  fill: #fffdf9;
  stroke: rgba(22, 86, 74, 0.62);
  stroke-width: 2;
  transition: fill 0.18s ease, stroke 0.18s ease;
}
.nd-no {
  position: relative;
  font-family: var(--serif);
  font-size: 15px;
  font-weight: 600;
  letter-spacing: 0.03em;
  color: var(--moss);
  transition: color 0.18s ease;
}
.nd-label {
  font-size: 12.5px;
  font-weight: 500;
  line-height: 1.5;
  color: var(--ink);
  white-space: nowrap;
  padding: 0 6px;
  border-radius: 4px;
  background: color-mix(in srgb, var(--paper-2) 82%, transparent);
}
.nd-en {
  font-size: 8px;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: rgba(35, 38, 31, 0.42);
  white-space: nowrap;
  text-shadow: 0 0 3px var(--paper-2), 0 0 3px var(--paper-2), 0 0 6px var(--paper-2);
}
.nd-badge {
  position: absolute;
  top: -3px;
  right: -3px;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 999px;
  background: #b3261e;
  color: #fff;
  font-size: 9.5px;
  font-weight: 600;
  display: grid;
  place-items: center;
  line-height: 1;
  box-shadow: 0 0 0 2px var(--paper-2);
}
.pt-node:hover .nd-shape polygon,
.pt-node:focus-visible .nd-shape polygon {
  fill: var(--moss);
  stroke: var(--moss);
}
.pt-node:hover .nd-no,
.pt-node:focus-visible .nd-no {
  color: #f6f2e8;
}
.pt-node:hover .nd-shape {
  transform: rotate(0deg) scale(calc(var(--s, 1) * 1.06));
}

/* 陶土赭只留给「AI」这一个节点：全屏唯一的第二个暖色 */
.pt-node.tn-ai .nd-shape polygon {
  stroke: var(--clay);
  stroke-dasharray: 4 3;
}
.pt-node.tn-ai .nd-no {
  color: var(--clay);
}
.pt-node.tn-ai:hover .nd-shape polygon {
  fill: var(--clay);
  stroke: var(--clay);
}
.pt-node.tn-ai:hover .nd-no {
  color: #fdf3ee;
}

/* 风险节点：形状不变，只把描边压深一档 */
.pt-node.tn-risk .nd-shape polygon {
  stroke: rgba(179, 38, 30, 0.55);
}
.pt-node.tn-risk .nd-no {
  color: #b3261e;
}

/* ---------- 底部 AI 输入条 ---------- */
.pt-dock {
  grid-area: 2 / 1 / 3 / 3;
  position: relative;
  z-index: 6;
  width: min(720px, calc(100% - 76px));
  margin: 2px auto 14px;
}
.ai-dock {
  width: 100%;
  height: 50px;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 0 8px 0 10px;
  border-radius: 14px;
  border: 1px solid var(--line-strong);
  background: #fffdf9;
  box-shadow: 0 8px 22px rgba(35, 38, 31, 0.07), 0 1px 2px rgba(35, 38, 31, 0.05);
  text-align: left;
  transition: border-color 0.18s ease, box-shadow 0.18s ease, transform 0.18s ease;
}
.ai-dock:hover {
  border-color: rgba(22, 86, 74, 0.5);
  box-shadow: 0 12px 28px rgba(22, 86, 74, 0.14);
  transform: translateY(-1px);
}
.dk-ava {
  flex: none;
  width: 28px;
  height: 28px;
  border-radius: 9px;
  display: grid;
  place-items: center;
  background: var(--moss);
  color: #f6f2e8;
  font-size: 10.5px;
  font-weight: 700;
  letter-spacing: 0.06em;
}
.dk-ph {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12.5px;
  color: var(--ink-3);
}
.dk-go {
  flex: none;
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 34px;
  padding: 0 12px;
  border-radius: 10px;
  background: rgba(22, 86, 74, 0.08);
  color: var(--moss);
  font-size: 12px;
  font-weight: 600;
}
.ai-dock:hover .dk-go {
  background: var(--moss);
  color: #f6f2e8;
}

/* ---------- 窄一点的桌面：左栏收窄，节点缩小 ---------- */
@media (max-width: 1280px) {
  .portal {
    grid-template-columns: minmax(252px, 30%) minmax(0, 1fr);
  }
  .pt-side {
    padding: 26px 18px 14px 26px;
  }
  .pt-hero {
    font-size: clamp(24px, 2.2vw, 30px);
    margin-top: 20px;
  }
  .pt-sub {
    font-size: 11.5px;
    line-height: 1.8;
    margin-top: 12px;
  }
  .pt-stats {
    margin-top: 14px;
  }
  .pt-node {
    width: calc(min(var(--nd, 76px), 64px) * 1.62);
  }
  .nd-shape {
    width: min(var(--nd, 76px), 64px);
    height: min(var(--nd, 76px), 64px);
  }
  .nd-label {
    font-size: 11.5px;
  }
  .pt-legend {
    display: none;
  }
  .pt-dock {
    width: calc(100% - 52px);
  }
  .pt-ghost span {
    font-size: clamp(38px, 5.4vw, 64px);
  }
}

/* ---------- 平板：左栏变成上方一条 ---------- */
@media (max-width: 960px) {
  .portal {
    grid-template-columns: minmax(0, 1fr);
    grid-template-rows: auto minmax(420px, 1fr) auto;
    height: auto;
  }
  .pt-side {
    grid-area: 1 / 1 / 2 / 2;
    padding: 22px 20px 6px;
  }
  .pt-hero {
    margin-top: 14px;
    font-size: clamp(24px, 4.4vw, 32px);
  }
  .pt-sub {
    max-width: none;
  }
  .pt-focus {
    margin-top: 16px;
  }
  .pt-canvas {
    grid-area: 2 / 1 / 3 / 2;
  }
  .pt-dock {
    grid-area: 3 / 1 / 4 / 2;
    margin: 8px auto 14px;
    width: calc(100% - 32px);
  }
}

/* ---------- 手机：节点改成两列网格，连线隐去 ---------- */
@media (max-width: 760px) {
  .portal {
    grid-template-rows: auto auto auto;
    border-radius: 12px;
  }
  .pt-side {
    padding: 18px 14px 4px;
  }
  .pt-mark {
    display: none;
  }
  .pt-hero {
    font-size: 24px;
  }
  .pt-sub {
    font-size: 11.5px;
    margin-top: 10px;
  }
  .pt-focus {
    margin-top: 14px;
    padding: 10px 10px 6px;
  }
  .pt-canvas {
    padding: 8px 10px 0;
  }
  /* 十一个节点压在 390 宽里一定打架，干脆改成两列网格 */
  .pt-field {
    position: relative;
    inset: auto;
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px 6px;
    margin-top: 6px;
    padding-bottom: 8px;
  }
  .pt-edges {
    display: none;
  }
  .pt-node {
    position: static;
    width: 100%;
    transform: none;
    gap: 2px;
  }
  .pt-node:hover,
  .pt-node:focus-visible {
    transform: translateY(-2px);
  }
  .nd-shape {
    width: min(var(--nd, 76px), 54px);
    height: min(var(--nd, 76px), 54px);
  }
  .nd-no {
    font-size: 11.5px;
  }
  .nd-label {
    font-size: 10.5px;
    padding: 0 3px;
  }
  .nd-en {
    display: none;
  }
  .pt-marks,
  .pt-crop,
  .pt-ghost,
  .pt-legend {
    display: none;
  }
  .pt-stars {
    opacity: 0.7;
  }
  .pt-dock {
    width: calc(100% - 24px);
    margin-bottom: 12px;
  }
  .dk-ph {
    font-size: 11.5px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .pt-node,
  .ai-dock,
  .nd-shape {
    transition: none;
  }
  .star {
    animation: none;
    opacity: 0.4 !important;
  }
}
</style>
