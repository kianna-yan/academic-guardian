"""学业护航 · FastAPI 服务入口。

前端为 Vue 3 + Vite 工程（web/），构建产物在 web/site，由本服务托管。
启动： python -m uvicorn app:app --port 8600
"""
from __future__ import annotations

import copy
import json
import os
import queue
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.middleware.gzip import GZipMiddleware
from pydantic import BaseModel

from engine import actions as actions_mod
from engine import accounts, checkin, classroom, curriculum, data, exporter, llm, notifications, rag, report as report_mod, simulator, trend
from engine.accounts import COUNSELOR_ACCOUNT
from engine.agent import Agent
from engine.letters import class_report, counselor_brief, parent_letter, student_letter
from engine.memory import ConversationMemory
from engine.notifications import APPEALS, MESSAGES, NOTIFS, TODOS
from engine.risk import DEFAULT_CONFIG, RiskEngine

BASE = Path(__file__).resolve().parent


def _load_env_file() -> None:
    """极简 .env 加载：不依赖 python-dotenv，避免线上托管环境缺包。

    线上发布默认不读 .env（本文件只用 os.environ），而 .env 里的大模型
    key 又不能进 git——这就导致线上 LLM_API_KEY 永远为空、llm.available()
    返回 False、自动降级走规则引擎，看起来像“没接大模型”。这里手动读
    .env 灌进 os.environ，已存在的环境变量不覆盖（线上若已注入同名变量
    则以线上为准，不会互相打架）。
    """
    env_path = BASE / ".env"
    if not env_path.exists():
        return
    for _line in env_path.read_text(encoding="utf-8").splitlines():
        _line = _line.strip()
        if not _line or _line.startswith("#") or "=" not in _line:
            continue
        _k, _, _v = _line.partition("=")
        _k, _v = _k.strip(), _v.strip()
        # 去掉两端可选的引号
        if len(_v) >= 2 and _v[0] == _v[-1] and _v[0] in ("'", '"'):
            _v = _v[1:-1]
        if _k and _k not in os.environ:
            os.environ[_k] = _v


_load_env_file()
DIST = BASE / "web" / "site"
LEGACY = BASE / "static"
STARTED_AT = time.time()
app = FastAPI(title="学业护航 Academic Guardian")

# 传输压缩：前端产物是 1.6 MB 未压缩的 JS，gzip 后约 400 KB。
# Starlette 的 GZip 默认把 text/event-stream 排除在外，所以 /api/chat/stream
# 的逐 token 推送不会被缓冲，打字机效果不受影响；Partial Content（断点续传）
# 与已带 Content-Encoding 的响应也会自动跳过。
app.add_middleware(GZipMiddleware, minimum_size=1024)

DATASET = data.db()
CONFIG = copy.deepcopy(DEFAULT_CONFIG)
ENGINE = RiskEngine(DATASET, CONFIG)
KB = rag.kb()
INTERVENTIONS: dict[str, list[dict]] = {}
COUNTER = {"n": 0}
ACCOUNTS = accounts.Accounts(DATASET["students"], BASE / "data" / "accounts.json",
                             teachers=DATASET.get("teachers", {}))
# 教务维护过的课程/教师档案优先于内置默认值
CURRICULUM = curriculum.Curriculum()
CURRICULUM.apply(DATASET)
# 课表与课后自评：记录落 data/checkins.json，只用于学习轨迹，不进风险分
CHECKINS = checkin.Checkins()
# 成绩试算方案：学生自己调的分配落 data/simulations.json，只存分数与权重
SIMS = simulator.Simulations(BASE / "data" / "simulations.json")
# 会话记忆：多轮对话的"他 / 第 N 个"靠它消解；按账号隔离
MEMORY = ConversationMemory()
# 消息中心：启动时把数据集里已发生的旷课/缺交/预警播种成各端的通知与待办
notifications.seed(ENGINE)


def _record_intervention(sid: str, title: str, note: str, status: str = "已完成") -> dict:
    """对话里说「记录：谈过了」，智能体直接写进干预台账。"""
    COUNTER["n"] += 1
    item = {
        "id": COUNTER["n"],
        "title": title,
        "status": status,
        "note": note,
        "created_at": datetime.now().strftime("%m-%d %H:%M"),
    }
    INTERVENTIONS.setdefault(sid, []).insert(0, item)
    return item


def _make_agent() -> Agent:
    from urllib.parse import quote

    def _send_parent_letter(sid: str) -> dict:
        """对话里的「把家长信发给家长」：SMTP 配置了就真发，否则给 .eml 下载。"""
        letter = _letter_of(sid, "parent")
        to = f"parent.{sid}@example.com"
        res = exporter.send_letter_email(letter, to)
        if not res["ok"]:
            return {"ok": False, "message": f"发送失败：{res.get('error', '未知错误')}"}
        if res["mode"] == "smtp":
            return {"ok": True, "mode": "smtp", "to": to}
        return {"ok": True, "mode": "eml", "to": to,
                "url": f"/api/export/send/{sid}?to={quote(to)}"}

    return Agent(ENGINE, KB, INTERVENTIONS, memory=MEMORY,
                 checkins=CHECKINS,
                 recorder=_record_intervention,
                 mailer=_send_parent_letter,
                 reporter=lambda: report_mod.daily_report(
                     ENGINE, INTERVENTIONS, week=DATASET.get("week")))


# ---------------------------------------------------------------------------
# 每日预警日报：定时聚合（默认每天 08:00；AG_REPORT_INTERVAL_MIN 设分钟间隔可演示），
# 结果挂在 REPORT_STATE 上，供对话问答、Word 导出与推送复用。
# ---------------------------------------------------------------------------
REPORT_STATE: dict = {"last_run": None, "last_report": None, "runs": 0}


def _build_report() -> dict:
    rep = report_mod.daily_report(ENGINE, INTERVENTIONS, week=DATASET.get("week"))
    REPORT_STATE["last_run"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    REPORT_STATE["last_report"] = rep
    REPORT_STATE["runs"] += 1
    return rep


def _report_due(now: datetime) -> bool:
    """到点判断：按天（默认 08:00）或按分钟间隔（演示模式）。"""
    interval_min = os.environ.get("AG_REPORT_INTERVAL_MIN")
    if interval_min:
        return (now - datetime.fromtimestamp(STARTED_AT)).total_seconds() / 60 >= float(interval_min)
    hour = int(os.environ.get("AG_REPORT_HOUR", "8"))
    return now.hour == hour and now.minute < 5


@app.on_event("startup")
async def _report_scheduler():
    """每 30 秒看一眼是否到点；到点就聚合一份日报挂到 REPORT_STATE。"""
    import asyncio

    async def loop():
        last_day = ""
        while True:
            now = datetime.now()
            if _report_due(now) and now.strftime("%Y-%m-%d") != last_day:
                try:
                    rep = _build_report()
                    last_day = now.strftime("%Y-%m-%d")
                    print(f"[日报] {rep['date']} 已生成：{rep['summary'][:48]}…")
                except Exception as exc:  # noqa: BLE001
                    print(f"[日报] 生成失败：{exc}")
            await asyncio.sleep(30)

    asyncio.create_task(loop())


# ---------------------------------------------------------------------------
# 鉴权：四个端各自独立登录，接口按角色隔离
# 公开接口只有健康检查、元信息和登录本身；其余一律要 Bearer token。
# ---------------------------------------------------------------------------
PUBLIC_API = {"/api/health", "/api/meta", "/api/auth/login"}


def _bearer(request: Request) -> str:
    """从请求里取本服务的登录 token。

    线上托管网关会往 `Authorization` 里塞平台自己的 JWT 并覆盖我们带的头，
    所以优先读自定义头 `X-Ag-Token`，其次读 query 的 `ag_token`（网关透传），
    最后才看 Authorization —— 且只认本服务签发的格式（恰好一个"."，JWT 是两个）。
    """
    raw = (request.headers.get("x-ag-token") or "").strip()
    if raw:
        return raw
    raw = (request.query_params.get("ag_token") or "").strip()
    if raw:
        return raw
    raw = (request.headers.get("authorization") or "").strip()
    if raw.lower().startswith("bearer "):
        cand = raw[7:].strip()
        if cand.count(".") == 1:
            return cand
    return ""


def _deny(profile: dict, method: str, path: str) -> str:
    """越权校验：学生只能看自己，家长只能看孩子，教务才有配置与导入权。"""
    role = profile.get("role")
    own = profile.get("sid")
    parts = [p for p in path.strip("/").split("/") if p]
    # parts: ["api", ...]

    def target_sid() -> str | None:
        if len(parts) >= 3 and parts[1] in ("students", "letters"):
            return parts[2]
        if len(parts) >= 3 and parts[1] == "interventions":
            return parts[2]
        # 导出路径：/api/export/letter/{sid}、/api/export/notice/{sid}、/api/export/send/{sid}
        if len(parts) >= 4 and parts[1] == "export" and parts[2] in ("letter", "notice", "send"):
            return parts[3]
        return None

    if role in ("student", "parent"):
        if path == "/api/students":
            return "该账号无查看全校名单的权限"
        if path.startswith("/api/reports"):
            return "该账号无生成班级报告的权限"
        if path == "/api/overview":
            return "该账号无查看全校看板的权限"
        if path == "/api/config" or path.startswith("/api/config/"):
            return "该账号无修改规则的权限"
        if path.startswith("/api/auth/import-students") or path.startswith("/api/auth/accounts"):
            return "该账号无账号管理权限"
        if path.startswith("/api/curriculum"):
            return "该账号无查看课程与教师档案的权限"
        sid = target_sid()
        if sid and sid != own:
            return "只能查看本人/孩子的学业数据"
        if sid and method == "POST" and parts[1] == "interventions" and role == "parent":
            return "家长端仅可查看，不可提交处理记录"
        # 课表/课后自评只能由学生本人写：家长看得到孩子的轨迹，但不能替孩子记录
        if role == "parent" and method != "GET" and sid:
            return "家长端仅可查看，课后记录需学生本人提交"
    elif role == "counselor":
        if path == "/api/config" and method == "POST":
            return "只有教务端可以修改预警规则"
        if path.startswith("/api/auth/import-students") or path.startswith("/api/auth/accounts"):
            return "只有教务端可以管理账号"
        if path.startswith("/api/curriculum") and method == "POST":
            return "只有教务端可以维护课程与教师档案"
    return ""


@app.middleware("http")
async def auth_guard(request: Request, call_next):
    path = request.url.path
    if not path.startswith("/api/") or path in PUBLIC_API:
        return await call_next(request)

    profile = ACCOUNTS.profile_of(_bearer(request))
    if not profile:
        return JSONResponse({"detail": "登录已过期，请重新登录"}, status_code=401)

    denied = _deny(profile, request.method, path)
    if denied:
        return JSONResponse({"detail": denied}, status_code=403)

    request.state.profile = profile
    return await call_next(request)


class ChatIn(BaseModel):
    role: str = "student"
    sid: str | None = None
    message: str


class ConfigIn(BaseModel):
    red_line: float
    yellow_line: float
    absence_warn_ratio: float | None = None
    midterm_fail_trigger: int | None = None


class InterventionIn(BaseModel):
    title: str
    status: str = "进行中"
    note: str = ""


class LoginIn(BaseModel):
    role: str
    account: str
    password: str


class PasswordIn(BaseModel):
    old_password: str
    new_password: str


class ImportIn(BaseModel):
    text: str = ""


class AppealIn(BaseModel):
    kind: str = "attendance"       # attendance 考勤 | homework 作业
    record_id: str = ""
    course: str = ""
    reason: str = ""


class AppealResolveIn(BaseModel):
    action: str = "accept"         # accept 同意更正 | reject 维持原记录
    reply: str = ""


class ReadIn(BaseModel):
    ids: list[str] = []


class MessageSendIn(BaseModel):
    sid: str           # 学生学号：家长发时=自己孩子，导员发时=指定学生
    text: str


class MessageReadIn(BaseModel):
    thread_id: str


def _scope(profile: dict, body: ChatIn) -> tuple[str, str | None]:
    """对话的身份由登录态决定，前端传什么都不能越权。"""
    role = profile.get("role") or "student"
    if role in ("student", "parent"):
        return role, profile.get("sid")
    return role, body.sid


def rebuild():
    global ENGINE
    ENGINE = RiskEngine(DATASET, CONFIG)
    return ENGINE


def _demo_students() -> dict:
    rows = ENGINE.roster()
    student = next((r for r in rows if r["level"] == "yellow" and r["delta"] > 8), rows[60])
    parent = next((r for r in rows if r["level"] == "red"), rows[0])
    return {"student": student["id"], "parent": parent["id"], "counselor": student["id"],
            "teacher": "2024014501"}


def _seed_demo_checkins() -> None:
    """演示用：默认演示学生名下没有课后记录时，先生成一份。

    登录页的「学生」提示按钮登录的正是 _demo_students() 选出来的这位同学，
    他如果一条记录都没有，学习轨迹首次打开就是空的，看起来像功能坏了。
    只补空账号，已有记录一律不动——学生自己写的永远优先。
    """
    try:
        demo = _demo_students()
        for sid in dict.fromkeys([demo["student"], demo["parent"]]):
            if not CHECKINS.rows(sid):
                added = CHECKINS.demo(sid)
                if added:
                    print(f"[演示] 已为 {sid} 生成 {added} 条课后记录")
    except Exception as exc:  # noqa: BLE001
        # 示例数据只影响演示效果，绝不能因为它在启动阶段把服务拦下来
        print(f"[演示] 课后记录初始化跳过：{exc}")


_seed_demo_checkins()


def _entry_html() -> Path:
    """优先返回 Vite 构建产物；没有构建时回退到旧版 static/，方便随时回滚。"""
    if (DIST / "index.html").exists():
        return DIST / "index.html"
    return LEGACY / "index.html"


# 入口 HTML 绝对不能缓存：一旦浏览器/网关留着上一版 index.html，
# 它引用的 assets/index-<旧hash>.js 会随新部署被删掉，用户看到的就是
# {"detail":"Not Found"} 或白屏。带 hash 的静态资源反而可以长期缓存。
_NO_STORE = {"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache"}


_ENTRY_CACHE: dict = {"mtime": 0.0, "html": ""}


def _entry_response():
    """返回入口 HTML。

    Vite 的 base 是 "./"，产物里是 href="./assets/…"。单段路由（/student）下没问题，
    但 /student/schedule 这种两级路径会把 "./assets/…" 解析成 /student/assets/… 而 404，
    页面就停在骨架屏上。这里在出站时统一改成根绝对路径，深链接和刷新都能正常加载。
    """
    path = _entry_html()
    if path.suffix == ".html":
        try:
            mtime = path.stat().st_mtime
            if _ENTRY_CACHE["mtime"] != mtime:
                html = path.read_text(encoding="utf-8")
                html = html.replace('"./assets/', '"/assets/').replace("'./assets/", "'/assets/")
                _ENTRY_CACHE.update(mtime=mtime, html=html)
            return Response(_ENTRY_CACHE["html"], media_type="text/html", headers=_NO_STORE)
        except OSError:
            pass
    return FileResponse(path, headers=_NO_STORE)


@app.get("/")
def index():
    return _entry_response()


@app.post("/api/auth/login")
def auth_login(body: LoginIn):
    try:
        result = ACCOUNTS.login(body.role, body.account, body.password)
    except accounts.AccountError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, **result}


@app.get("/api/auth/me")
def auth_me(request: Request):
    profile = getattr(request.state, "profile", None) or {}
    return {
        "profile": profile,
        "stats": ACCOUNTS.stats(),
        "defaults": accounts.DEFAULT_PASSWORD,
        "staff_accounts": {
            "counselor": accounts.COUNSELOR_ACCOUNT,
            "admin": accounts.ADMIN_ACCOUNT,
        },
    }


@app.post("/api/auth/change-password")
def auth_change_password(body: PasswordIn, request: Request):
    profile = getattr(request.state, "profile", None) or {}
    try:
        updated = ACCOUNTS.change_password(profile, body.old_password, body.new_password)
    except accounts.AccountError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "profile": updated}


@app.get("/api/auth/accounts")
def auth_accounts(limit: int = Query(200, ge=1, le=500)):
    return {"rows": ACCOUNTS.account_list(limit=limit), "stats": ACCOUNTS.stats()}


@app.post("/api/auth/import-students")
def auth_import_students(body: ImportIn):
    try:
        return ACCOUNTS.import_students(body.text)
    except accounts.AccountError as e:
        raise HTTPException(400, str(e))


@app.get("/api/meta")
def meta():
    demo = _demo_students()
    return {
        "roles": [
            {"key": "student", "name": "学生端", "desc": "自查风险 · 补救路径"},
            {"key": "counselor", "name": "辅导员端", "desc": "风险名单 · 谈话跟进"},
            {"key": "admin", "name": "教务端", "desc": "规则配置 · 全校看板"},
            {"key": "parent", "name": "家长端", "desc": "情况沟通 · 家校联动"},
            {"key": "teacher", "name": "教师端", "desc": "任课视角 · 课堂学情"},
        ],
        "classes": DATASET["classes"],
        "schools": KB.schools(),
        "config": CONFIG,
        "llm": llm.status(),
        "term": DATASET["term"],
        "week": DATASET["week"],
        "demo": demo,
        "student_count": len(DATASET["students"]),
        "updated_at": DATASET["updated_at"],
    }


@app.get("/api/overview")
def overview():
    return ENGINE.overview()


@app.get("/api/students")
def students(
    class_name: str | None = Query(None),
    level: str | None = Query(None),
    limit: int = Query(300, ge=1, le=300),
):
    rows = ENGINE.roster(class_name, level)
    return {"total": len(rows), "rows": rows[:limit]}


@app.get("/api/students/{sid}")
def student_detail(sid: str):
    try:
        s = ENGINE.get(sid)
    except KeyError:
        raise HTTPException(404, "学生不存在")
    r = ENGINE.score(sid)
    plan = ENGINE.advice(sid, r)
    # 成绩走势：班级均分从课程统计里补，避免 trend 模块重复算全校数据
    gt = trend.grade_trend(s)
    for c in gt["courses"]:
        stat = ENGINE.course_stats.get(c["code"])
        if stat:
            c["cohort_avg"] = stat["mean"]
    return {
        "student": {
            "id": s["id"], "name": s["name"], "gender": s["gender"], "class_name": s["class_name"],
            "major": s["major"], "grade": s["grade"], "advisor": s["advisor"], "term": s["term"],
            "credits": s["credits"], "history": s["history"], "engagement": s["engagement"],
        },
        "risk": r,
        "courses": s["courses"],
        "extra_courses": s.get("extra_courses", []),
        "actions": plan["actions"],
        "advice": plan,
        "grade_trend": gt,
        "interventions": INTERVENTIONS.get(sid, []),
    }


# ---------------------------------------------------------------------------
# 课表 / 课后自评 / 学习轨迹
# 路径统一挂在 /api/students/{sid}/ 下，_deny 里的 target_sid() 会自动接管，
# 学生只能读写自己的课表与记录，家长只能看不能代记。
# ---------------------------------------------------------------------------
class CheckinIn(BaseModel):
    course: str
    date: str
    period: str
    understand: str = "full"      # full 听懂 | fuzzy 有点模糊 | lost 没听懂
    break_at: str = "none"        # 从什么时候开始没听懂
    break_minute: int | None = None
    point: str = ""
    plan: str = "none"
    note: str = ""


def _require_student(sid: str) -> None:
    if sid not in {s["id"] for s in DATASET["students"]}:
        raise HTTPException(404, "学生不存在")


@app.get("/api/students/{sid}/timetable")
def student_timetable(sid: str, week: int | None = Query(None, ge=1, le=16)):
    """某一教学周的课表：一格一节课，已上过的带出学生自己的记录。"""
    _require_student(sid)
    index = CHECKINS.index(sid)
    payload = checkin.timetable(week or DATASET.get("week") or 1, index, DATASET)
    payload["term"] = DATASET.get("term")
    # 图例用：这门课这学期总共记了多少、断了几次，点格子时不用再查一遍
    payload["courses"] = [
        {
            "code": c["code"],
            "name": c["name"],
            "teacher": c["teacher"],
            "room": checkin.ROOMS.get(c["code"], ""),
            "kind": c.get("kind", ""),
            "credit": c.get("credit", 0),
        }
        for c in checkin.COURSES
    ]
    payload["today_sessions"] = [s for s in payload["slots"] if s["today"]]
    return payload


@app.get("/api/students/{sid}/checkins")
def student_checkins(sid: str, course: str | None = Query(None)):
    _require_student(sid)
    rows = CHECKINS.rows(sid, course)
    return {
        "rows": checkin.timeline(rows),
        "persistent": CHECKINS.persistent,
        "states": checkin.UNDERSTAND,
        "break_options": [{"key": k, "label": v[0]} for k, v in checkin.BREAK_AT.items()],
        "plans": checkin.PLANS,
        "points": checkin.POINTS,
    }


@app.post("/api/students/{sid}/checkin")
def student_checkin_save(sid: str, body: CheckinIn):
    _require_student(sid)
    try:
        row = CHECKINS.upsert(sid, body.model_dump())
    except checkin.CheckinError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "record": row, "persistent": CHECKINS.persistent}


@app.delete("/api/students/{sid}/checkin")
def student_checkin_delete(sid: str, id: str = Query(...)):
    _require_student(sid)
    if not CHECKINS.remove(sid, id):
        raise HTTPException(404, "没有这条记录")
    return {"ok": True}


@app.post("/api/students/{sid}/checkins/demo")
def student_checkin_demo(sid: str):
    """演示用：按这位学生的期中成绩生成近几周的自评记录（可随时改或删）。"""
    _require_student(sid)
    added = CHECKINS.demo(sid)
    return {"ok": True, "added": added}


@app.get("/api/students/{sid}/track")
def student_track(sid: str):
    """学习轨迹：每门课一条线，标出断点从哪开始、哪一节接上。"""
    _require_student(sid)
    return checkin.track(sid, CHECKINS.rows(sid), DATASET)


# ---------------------------------------------------------------------------
# 成绩分配试算
# 权重按课程性质给默认方案，起点分全部来自学生自己的真实明细（随堂测/期中/出勤/作业）。
# 结论不下发：前端改一下滑杆就重算，省一次往返；保存的是"分配方案"本身。
# ---------------------------------------------------------------------------
class SimPlanIn(BaseModel):
    scores: dict[str, float] = {}
    weights: dict[str, float] = {}


class SimSaveIn(BaseModel):
    plans: dict[str, SimPlanIn] = {}
    action: str = "save"      # save 保存 | reset 清空回到初始分配


@app.get("/api/students/{sid}/simulate")
def student_simulate(sid: str):
    _require_student(sid)
    student = ENGINE.get(sid)
    payload = simulator.payload(student, ENGINE.score(sid), DATASET.get("term"))
    payload["saved"] = SIMS.get(sid)
    payload["persistent"] = SIMS.persistent
    return payload


@app.post("/api/students/{sid}/simulate")
def student_simulate_save(sid: str, body: SimSaveIn):
    _require_student(sid)
    stamp = datetime.now().strftime("%m-%d %H:%M")
    if body.action == "reset":
        saved = SIMS.clear(sid)
    else:
        saved = SIMS.save(sid, {code: p.model_dump() for code, p in body.plans.items()}, stamp)
    return {"ok": True, "saved": saved, "persistent": SIMS.persistent}


@app.get("/api/curriculum")
def curriculum_list():
    return CURRICULUM.payload(DATASET)


@app.post("/api/curriculum/import")
def curriculum_import(body: ImportIn):
    result = CURRICULUM.import_text(body.text or "", {c["code"] for c in DATASET["courses"]})
    if result["ok"]:
        CURRICULUM.apply(DATASET)
        rebuild()
    return result


@app.get("/api/letters/{sid}")
def letters(sid: str, type: str = Query("student")):
    if sid not in {s["id"] for s in DATASET["students"]}:
        raise HTTPException(404, "学生不存在")
    school = CONFIG.get("school")
    if type == "parent":
        return parent_letter(ENGINE, KB, sid, school)
    if type == "counselor":
        return counselor_brief(ENGINE, KB, sid, school)
    return student_letter(ENGINE, KB, sid, school)


@app.get("/api/reports/{class_name}")
def report(class_name: str):
    return class_report(ENGINE, class_name)


@app.get("/api/policy")
def policy(q: str, school: str | None = None):
    hits = KB.search(q, top_k=4, school=school)
    return {"query": q, "hits": hits}


@app.post("/api/chat")
def chat(body: ChatIn, request: Request):
    role, sid = _scope(request.state.profile, body)
    agent = _make_agent()
    return agent.answer(role, sid, body.message, CONFIG.get("school"),
                        profile=request.state.profile)


@app.get("/api/agent/briefing")
def agent_briefing(request: Request):
    """主动简报：各端进页面时智能体先开口，页面是它的仪表盘。"""
    profile = request.state.profile
    role = profile.get("role") or "student"
    sid = profile.get("sid")
    agent = _make_agent()
    return agent.briefing(role, sid, profile)


@app.get("/api/teacher/view")
def teacher_view(request: Request):
    """任课教师视角的数据：他教的课 + 课上的学生（含风险分与该课明细）。"""
    profile = request.state.profile
    if profile.get("role") != "teacher":
        raise HTTPException(403, "仅任课教师可访问")
    teacher_name = profile.get("advisor") or profile.get("name") or ""
    return ENGINE.teacher_view(teacher_name)


def _teacher_scope(request: Request) -> str:
    """教师只能看自己：名字一律从登录态取，前端传什么都不作数。"""
    profile = request.state.profile
    if profile.get("role") != "teacher":
        raise HTTPException(403, "仅任课教师可访问")
    return profile.get("advisor") or profile.get("name") or ""


@app.get("/api/teacher/classroom")
def teacher_classroom(request: Request):
    """课堂学情：以「我教的这门课」为统计单位，而不是以学生为单位。"""
    teacher_name = _teacher_scope(request)
    return classroom.report(
        ENGINE, teacher_name,
        teacher_profile=DATASET.get("teachers", {}).get(teacher_name),
        term=DATASET.get("term", ""),
        week=DATASET.get("week", 0),
    )


# ---------------------------------------------------------------------------
# 教师上传资源（历年真题 / 网课），可被学生端拉取
# 演示场景把文件落到 data/teacher_resources/，metadata 写入同目录 index.json；
# 线上若挂载为只读，写盘失败会退化成内存态（本次进程内仍可用，重启清空）。
# ---------------------------------------------------------------------------
RESOURCE_DIR = BASE / "data" / "teacher_resources"
RESOURCE_INDEX = RESOURCE_DIR / "index.json"
_resources_lock = threading.Lock()


def _resources_load() -> list[dict]:
    try:
        if RESOURCE_INDEX.exists():
            return json.loads(RESOURCE_INDEX.read_text(encoding="utf-8"))
    except Exception:
        pass
    return []


def _resources_save(rows: list[dict]) -> None:
    try:
        RESOURCE_DIR.mkdir(parents=True, exist_ok=True)
        RESOURCE_INDEX.write_text(
            json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except OSError:
        # 线上只读挂载：退化成内存态，列表接口仍能返回本次进程内的数据
        pass


def _resource_visible(row: dict, profile: dict) -> bool:
    """教师只看自己的；学生看所有；其他端不可见。"""
    role = profile.get("role")
    if role == "teacher":
        return row.get("teacher") == (profile.get("advisor") or profile.get("name"))
    if role == "student":
        return True
    return False


@app.get("/api/teacher/resources")
def teacher_resources_list(request: Request, kind: str = Query("", description="exam|tutorial|空=全部")):
    """教师看自己上传的；学生看所有老师上传的；其他端 403。"""
    profile = request.state.profile
    role = profile.get("role")
    if role not in ("teacher", "student"):
        raise HTTPException(403, "仅任课教师与学生可访问资源库")
    rows = _resources_load()
    rows = [r for r in rows if _resource_visible(r, profile)]
    if kind:
        rows = [r for r in rows if r.get("kind") == kind]
    # 最新的在前
    rows.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return {"items": rows}


@app.post("/api/teacher/resources")
async def teacher_resources_upload(
    request: Request,
    file: UploadFile = File(...),
    kind: str = Form(..., description="exam 真题 / tutorial 网课"),
    course: str = Form(""),
    class_name: str = Form(""),
    note: str = Form(""),
):
    """教师上传一份真题或网课资源。学生端可拉取下载。"""
    profile = request.state.profile
    if profile.get("role") != "teacher":
        raise HTTPException(403, "仅任课教师可上传资源")
    if kind not in ("exam", "tutorial"):
        raise HTTPException(400, "kind 只能是 exam 或 tutorial")
    teacher_name = profile.get("advisor") or profile.get("name") or ""
    # 限制 50 MB，避免大文件撑爆沙箱
    content = await file.read()
    if len(content) > 50 * 1024 * 1024:
        raise HTTPException(413, "单个文件不超过 50 MB")
    rid = f"r{int(time.time()*1000)}_{uuid.uuid4().hex[:8]}"
    filename = (file.filename or "").strip() or "untitled"
    # 文件名加上 rid 前缀防冲突，保留原名用于展示
    safe_name = filename.replace("/", "_").replace("\\", "_")
    stored = RESOURCE_DIR / f"{rid}__{safe_name}"
    try:
        RESOURCE_DIR.mkdir(parents=True, exist_ok=True)
        stored.write_bytes(content)
    except OSError as e:
        raise HTTPException(500, f"保存失败：{e}")
    row = {
        "id": rid,
        "kind": kind,
        "filename": filename,
        "size": len(content),
        "course": course.strip(),
        "class_name": class_name.strip(),
        "note": note.strip(),
        "teacher": teacher_name,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    with _resources_lock:
        rows = _resources_load()
        rows.append(row)
        _resources_save(rows)
    return {"ok": True, "item": row}


@app.delete("/api/teacher/resources/{rid}")
def teacher_resources_delete(rid: str, request: Request):
    """删除自己上传的一份资源（含文件本体）。"""
    profile = request.state.profile
    if profile.get("role") != "teacher":
        raise HTTPException(403, "仅任课教师可删除资源")
    teacher_name = profile.get("advisor") or profile.get("name") or ""
    with _resources_lock:
        rows = _resources_load()
        hit = next((r for r in rows if r.get("id") == rid), None)
        if not hit:
            raise HTTPException(404, "资源不存在")
        if hit.get("teacher") != teacher_name:
            raise HTTPException(403, "只能删除自己上传的资源")
        rows = [r for r in rows if r.get("id") != rid]
        _resources_save(rows)
    # 删文件本体（不存在就跳过）
    target = RESOURCE_DIR / f"{rid}__{hit['filename'].replace('/', '_').replace(chr(92), '_')}"
    try:
        if target.exists():
            target.unlink()
    except OSError:
        pass
    return {"ok": True}


@app.get("/api/teacher/resources/{rid}/download")
def teacher_resources_download(rid: str, request: Request):
    """下载资源：教师与学生均可。"""
    profile = request.state.profile
    if profile.get("role") not in ("teacher", "student"):
        raise HTTPException(403, "仅任课教师与学生可下载资源")
    rows = _resources_load()
    hit = next((r for r in rows if r.get("id") == rid), None)
    if not hit:
        raise HTTPException(404, "资源不存在")
    if not _resource_visible(hit, profile):
        raise HTTPException(403, "无权访问该资源")
    safe = hit["filename"].replace("/", "_").replace("\\", "_")
    target = RESOURCE_DIR / f"{rid}__{safe}"
    if not target.exists():
        raise HTTPException(404, "文件已不存在")
    return FileResponse(
        target,
        filename=safe,
        media_type="application/octet-stream",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/api/export/classroom")
def export_classroom(request: Request):
    """课堂学情简报 → Word（教师端专属，其他端没有这个文书）。"""
    teacher_name = _teacher_scope(request)
    payload = classroom.report(
        ENGINE, teacher_name,
        teacher_profile=DATASET.get("teachers", {}).get(teacher_name),
        term=DATASET.get("term", ""),
        week=DATASET.get("week", 0),
    )
    stamp = datetime.now().strftime("%Y%m%d")
    return _file_stream(exporter.classroom_docx(payload),
                        f"课堂学情简报_{teacher_name}_{stamp}.docx", _DOCX_MIME)


@app.post("/api/agent/reset")
def agent_reset(request: Request):
    """清空本账号的会话记忆（换个思路重新聊）。"""
    from engine.memory import memory_key
    MEMORY.clear(memory_key(request.state.profile))
    return {"ok": True}


# ---------------------------------------------------------------------------
# 消息中心：四端通知 / 待办 / 学生异议闭环
# 学生端收到：旷课、缺交、预警、异议回执；导员端收到：学生异议、约谈提醒。
# 每端只看得到自己的消息（role:account 隔离），互不串台。
# ---------------------------------------------------------------------------
def _nkey(profile: dict) -> tuple[str, str]:
    return profile.get("role") or "student", profile.get("account") or "anon"


_KIND_LABEL = {"attendance": "旷课记录", "homework": "作业缺交记录"}


@app.get("/api/notifications")
def notifications_get(request: Request):
    """本账号的未读通知 + 待办 +（学生端）自己的异议进度。"""
    p = request.state.profile
    role, account = _nkey(p)
    unread = NOTIFS.unread(role, account)
    todos = TODOS.items(role, account)
    out: dict = {
        "unread": unread,
        "todos": todos,
        "counts": {"unread": len(unread), "todo": sum(1 for t in todos if not t["done"])},
    }
    if p.get("role") == "student" and p.get("sid"):
        mine = APPEALS.by_student(p["sid"])
        out["appeals"] = mine
        out["counts"]["appeals_pending"] = sum(1 for a in mine if a["status"] == "pending")
    return out


@app.post("/api/notifications/read")
def notifications_read(body: ReadIn, request: Request):
    role, account = _nkey(request.state.profile)
    n = NOTIFS.mark_read(role, account, body.ids)
    return {"ok": True, "marked": n}


@app.post("/api/todos/{tid}/finish")
def todo_finish(tid: str, request: Request):
    """勾掉一条待办（本账号自己的）。"""
    p = request.state.profile
    role, account = _nkey(p)
    row = TODOS.finish(role, account, tid)
    if not row:
        raise HTTPException(404, "待办不存在")
    return {"ok": True, "todo": row}


@app.post("/api/appeals")
def appeal_submit(body: AppealIn, request: Request):
    """学生对某条考勤/作业记录提出异议 → 实时生成导员端通知 + 待办。"""
    p = request.state.profile
    if p.get("role") != "student":
        raise HTTPException(403, "只有学生端可以提交异议")
    reason = (body.reason or "").strip()
    if len(reason) < 5:
        raise HTTPException(400, "请填写异议理由（至少 5 个字），方便老师核实")
    label = _KIND_LABEL.get(body.kind, "考勤记录")
    row = APPEALS.submit(p, body.kind, body.record_id, body.course, reason)
    NOTIFS.push("counselor", COUNSELOR_ACCOUNT, "appeal_new",
                f"{p.get('name', '学生')} 对{label}提出异议",
                f"《{body.course}》（{body.record_id}）：{reason[:60]}",
                {"appeal_id": row["id"]})
    TODOS.push("counselor", COUNSELOR_ACCOUNT, "appeal",
               f"处理 {p.get('name', '学生')} 的{label}异议",
               f"《{body.course}》：{reason[:50]}——在消息面板可直接同意或驳回。",
               {"appeal_id": row["id"]})
    return {"ok": True, "appeal": row}


@app.get("/api/appeals")
def appeal_list(request: Request):
    """学生看自己的异议进度；导员看名下学生的异议；教务看全部。"""
    p = request.state.profile
    role = p.get("role")
    if role == "student":
        rows = APPEALS.by_student(p.get("sid") or "")
    elif role == "admin":
        rows = APPEALS.all()
    else:
        rows = APPEALS.by_advisor(p.get("name") or "刘畅")
    return {"items": rows}


@app.post("/api/appeals/{aid}/resolve")
def appeal_resolve(aid: str, body: AppealResolveIn, request: Request):
    """导员/教务裁定异议 → 学生端收到回执通知，导员端对应待办自动闭环。"""
    p = request.state.profile
    if p.get("role") not in ("counselor", "admin"):
        raise HTTPException(403, "只有辅导员或教务可以处理异议")
    row = APPEALS.get(aid)
    if not row:
        raise HTTPException(404, "异议不存在")
    if row["status"] != "pending":
        raise HTTPException(400, "这条异议已处理过了")
    reply = (body.reply or "").strip()
    row = APPEALS.resolve(aid, body.action, reply)
    verdict = "已核实，将更正记录" if row["status"] == "accepted" else "核实后维持原记录"
    NOTIFS.push("student", row["sid"], "appeal_reply",
                f"你的{ _KIND_LABEL.get(row['kind'], '记录')}异议有了结果",
                f"《{row['course']}》：{verdict}。{reply}".strip(),
                {"appeal_id": aid})
    TODOS.push("student", row["sid"], "appeal", "查看异议处理结果",
               f"《{row['course']}》的异议{verdict}，点开消息中心看老师回复。",
               {"appeal_id": aid})
    TODOS.close_by_meta("counselor", COUNSELOR_ACCOUNT, {"appeal_id": aid})
    return {"ok": True, "appeal": row}


# ---------------------------------------------------------------------------
# 家长端 ↔ 辅导员端 双向消息：以学生 sid 为配对键
# 家长发：to=counselor/COUNSELOR_ACCOUNT；导员发：to=parent/{sid}
# ---------------------------------------------------------------------------
@app.get("/api/messages")
def messages_list(request: Request):
    """家长：自己和导员的会话；导员：与各家长的会话列表。

    导员端要展示「风险高的学生优先」的会话列表——哪怕还没发过消息的学生
    也要列出来，方便导员主动联系。所以这里把 students 增强（带 level/score/
    top_factor），让 threads_for 能按风险排序、补全没消息的会话。
    """
    p = request.state.profile
    role = p.get("role")
    if role not in ("parent", "counselor"):
        raise HTTPException(403, "只有家长端和辅导员端可以使用家校消息")
    students = None
    if role == "counselor":
        # 给每个学生带上风险等级/分数/主因，让前端列表能按风险展示
        students = []
        for s in DATASET["students"]:
            sc = ENGINE.score(s["id"])
            students.append({
                "id": s["id"], "name": s["name"],
                "class_name": s.get("class_name", ""),
                "advisor": s.get("advisor", ""),
                "level": sc["level"], "score": sc["score"],
                "top_factor": sc["factors"][0]["label"] if sc["factors"] else "",
            })
    threads = MESSAGES.threads_for(role, p.get("account") or "", students=students)
    return {"threads": threads, "unread": MESSAGES.unread_count(role, p.get("account") or "")}


@app.post("/api/messages/send")
def messages_send(body: MessageSendIn, request: Request):
    p = request.state.profile
    role = p.get("role")
    sid = (body.sid or "").strip()
    text = (body.text or "").strip()
    if not sid:
        raise HTTPException(400, "缺少学生学号")
    if not text:
        raise HTTPException(400, "消息内容不能为空")
    if len(text) > 500:
        raise HTTPException(400, "单条消息不超过 500 字")
    from_name = p.get("name") or ""
    if role == "parent":
        # 家长只能就自己孩子发消息，sid 必须等于自己账号
        if sid != p.get("account"):
            raise HTTPException(403, "只能就自己的孩子与辅导员沟通")
        msg = MESSAGES.send("parent", sid, from_name,
                            "counselor", COUNSELOR_ACCOUNT, "辅导员", text, sid)
    elif role == "counselor":
        # 导员可以就任意学生发消息给其家长
        if sid not in {s["id"] for s in DATASET["students"]}:
            raise HTTPException(404, "学生不存在")
        stu = ENGINE.get(sid)
        to_name = f"{stu['name']} 家长"
        msg = MESSAGES.send("counselor", COUNSELOR_ACCOUNT, from_name,
                            "parent", sid, to_name, text, sid)
    else:
        raise HTTPException(403, "只有家长端和辅导员端可以发送家校消息")
    return {"ok": True, "message": msg}


@app.post("/api/messages/read")
def messages_read(body: MessageReadIn, request: Request):
    p = request.state.profile
    role = p.get("role")
    if role not in ("parent", "counselor"):
        raise HTTPException(403, "只有家长端和辅导员端可以使用家校消息")
    n = MESSAGES.mark_read(body.thread_id, role)
    return {"ok": True, "marked": n}


# ---------------------------------------------------------------------------
# 文书导出：Word（家长信/告知函/谈话要点/通知书/台账/日报）+ 学期汇报 PPT + 家长信邮件
# 浏览器 <a> 直接下载走 ag_token query 透传（_bearer 已支持）。
# ---------------------------------------------------------------------------
_DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
_PPTX_MIME = "application/vnd.openxmlformats-officedocument.presentationml.presentation"


def _file_stream(buf, filename: str, mime: str) -> StreamingResponse:
    from urllib.parse import quote
    return StreamingResponse(
        buf, media_type=mime,
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}"},
    )


def _letter_of(sid: str, letter_type: str) -> dict:
    school = CONFIG.get("school")
    if letter_type == "parent":
        return parent_letter(ENGINE, KB, sid, school)
    if letter_type == "counselor":
        return counselor_brief(ENGINE, KB, sid, school)
    return student_letter(ENGINE, KB, sid, school)


@app.get("/api/export/letter/{sid}")
def export_letter(sid: str, type: str = Query("parent")):
    """家长信 / 告知函 / 谈话要点 → Word（letters.py 原文排版）。"""
    letter = _letter_of(sid, type)
    stamp = datetime.now().strftime("%Y%m%d")
    return _file_stream(exporter.letter_docx(letter),
                        f"{letter['title']}_{stamp}.docx", _DOCX_MIME)


@app.get("/api/export/notice/{sid}")
def export_notice(sid: str):
    """学业预警通知书（存档联 + 回执）→ Word。"""
    stamp = datetime.now().strftime("%Y%m%d")
    s = ENGINE.get(sid)
    return _file_stream(exporter.notice_docx(ENGINE, sid),
                        f"学业预警通知书_{s['name']}_{stamp}.docx", _DOCX_MIME)


@app.get("/api/export/interventions")
def export_interventions(request: Request, sid: str | None = Query(None)):
    """干预台账 → Word。辅导员可带 sid 导单人；教务导全校。"""
    profile = request.state.profile
    if profile.get("role") not in ("counselor", "admin"):
        raise HTTPException(403, "仅辅导员与教务端可导出台账")
    scope = "全部学生"
    data_map = INTERVENTIONS
    if sid:
        data_map = {sid: INTERVENTIONS.get(sid, [])}
        scope = ENGINE.get(sid)["name"]
    return _file_stream(exporter.interventions_docx(data_map, ENGINE, scope=scope),
                        f"学业干预台账_{datetime.now().strftime('%Y%m%d')}.docx", _DOCX_MIME)


@app.get("/api/export/daily-report")
def export_daily_report(request: Request, fresh: int = Query(0)):
    """每日预警日报 → Word。fresh=1 现场重聚合（演示定时任务同款逻辑）。"""
    if request.state.profile.get("role") not in ("counselor", "admin"):
        raise HTTPException(403, "仅辅导员与教务端可导出日报")
    rep = _build_report() if fresh or not REPORT_STATE["last_report"] else REPORT_STATE["last_report"]
    return _file_stream(exporter.daily_report_docx(rep),
                        f"每日预警日报_{rep['date']}.docx", _DOCX_MIME)


@app.get("/api/export/semester")
def export_semester(request: Request):
    """学期汇报 → PPT（6 页：概览/班级排名/重点学生/干预成效/建议）。"""
    if request.state.profile.get("role") not in ("counselor", "admin"):
        raise HTTPException(403, "仅辅导员与教务端可导出学期汇报")
    rep = REPORT_STATE["last_report"] or _build_report()
    return _file_stream(exporter.semester_pptx(rep, ENGINE),
                        f"学业预警学期汇报_{datetime.now().strftime('%Y%m%d')}.pptx", _PPTX_MIME)


@app.get("/api/agent/daily-report")
def agent_daily_report(request: Request):
    """日报 JSON：对话里问「今日日报」与前端卡片都走这里。没有缓存就现场聚合。"""
    if request.state.profile.get("role") not in ("counselor", "admin"):
        raise HTTPException(403, "仅辅导员与教务端可查看日报")
    rep = REPORT_STATE["last_report"] or _build_report()
    return {
        "date": rep["date"], "week": rep["week"], "generated_at": rep["generated_at"],
        "scheduled_at": REPORT_STATE["last_run"], "runs": REPORT_STATE["runs"],
        "summary": rep["summary"], "body": rep["body"],
        "red_top": [{"name": x["name"], "class_name": x["class_name"], "score": x["score"]}
                    for x in rep["red_top"]],
        "rising": [{"name": x["name"], "class_name": x["class_name"],
                    "delta": x["delta"], "score": x["score"]} for x in rep["rising"]],
        "docx_url": "/api/export/daily-report",
        "smtp_configured": exporter.smtp_configured(),
    }


@app.get("/api/export/send/{sid}")
def export_send(sid: str, request: Request, to: str | None = Query(None)):
    """家长信邮件：SMTP（AG_SMTP_*）配置后由对话直接触发真实发送；
    未配置时本端点产出 .eml（收件人已填好，双击即进邮件客户端）——演示环境同样走完闭环。"""
    profile = request.state.profile
    if profile.get("role") not in ("counselor", "admin", "parent"):
        raise HTTPException(403, "学生端不能发送家长信")
    letter = _letter_of(sid, "parent")
    s = ENGINE.get(sid)
    to_addr = (to or "").strip() or f"parent.{sid}@example.com"
    res = exporter.send_letter_email(letter, to_addr)
    if not res["ok"]:
        raise HTTPException(502, f"邮件发送失败：{res.get('error', '未知错误')}")
    if res["mode"] == "smtp":
        return JSONResponse({"mode": "smtp", "ok": True, "to": to_addr,
                             "message": f"家长信已通过邮件发送给 {s['name']} 的家长（{to_addr}）。"})
    stamp = datetime.now().strftime("%Y%m%d")
    return _file_stream(res["eml"], f"家长信_{s['name']}_{stamp}.eml", "message/rfc822")


def _sse(event: str, data) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


def _chunks(text: str, size: int = 8):
    for i in range(0, len(text), size):
        yield text[i:i + size]


@app.get("/api/health")
def health():
    """轻量健康检查：沙箱刚唤醒、应用还没监听时，外部探活可以先用它确认。"""
    return {
        "ok": True,
        "pid": os.getpid(),
        "uptime_s": round(time.time() - STARTED_AT, 1),
        "dist": (DIST / "index.html").exists(),
        "legacy": (LEGACY / "index.html").exists(),
    }


@app.post("/api/chat/stream")
def chat_stream(body: ChatIn, request: Request):
    """SSE 流式对话。

    工具调用、回答增量、引用、建议分事件推送；Agent 在独立线程里跑，
    通过队列把中间事件转给生成器，所以"查了什么、查到什么"是实时可见的。
    """
    # 在进入生成器前就把身份定下来：生成器里拿不到 request.state 的可靠性不如这里
    role, sid = _scope(request.state.profile, body)
    profile = dict(request.state.profile)

    def gen():
        started = time.time()
        events: queue.Queue = queue.Queue()
        sentinel = object()
        # 客户端断开后置位，worker 就不再往队列里塞东西，避免线程和队列长期悬挂
        stop = threading.Event()

        def worker():
            try:
                agent = _make_agent()

                def emit(kind, payload):
                    if not stop.is_set():
                        events.put((kind, payload))

                result = agent.answer(
                    role, sid, body.message, CONFIG.get("school"),
                    emit=emit, profile=profile,
                )
                events.put(("final", result))
            except Exception as exc:  # noqa: BLE001
                events.put(("error", {"message": str(exc)}))
            finally:
                events.put(sentinel)

        threading.Thread(target=worker, daemon=True).start()

        final = None
        streamed_by_llm = False
        try:
            while True:
                try:
                    item = events.get(timeout=15)
                except queue.Empty:
                    # 空闲时发一个注释帧，避免隧道/代理把长连接判成挂死
                    yield ": ping\n\n"
                    continue
                if item is sentinel:
                    break
                kind, payload = item
                if kind == "meta":
                    yield _sse("meta", payload)
                elif kind == "thought":
                    yield _sse("thought", payload)
                elif kind == "tool":
                    yield _sse("tool", payload)
                elif kind == "delta":
                    streamed_by_llm = True
                    yield _sse("delta", payload)
                elif kind == "error":
                    yield _sse("error", payload)
                elif kind == "final":
                    final = payload
        finally:
            stop.set()

        if final is None:
            yield _sse("done", {"elapsed_ms": 0})
            return

        # 没有配置大模型时，把确定性回答切块推出，前端同样是流式观感
        if not streamed_by_llm:
            for piece in _chunks(final["reply"]):
                yield _sse("delta", {"text": piece})
                time.sleep(0.012)

        if final.get("citations"):
            yield _sse("citations", final["citations"])
        # 方案 C：回答末尾挂一张「要不要我替你做」的卡片，前端点了才执行
        if final.get("action"):
            yield _sse("action", final["action"])
        if final.get("suggestions"):
            yield _sse("suggestions", final["suggestions"])
        yield _sse("done", {
            "elapsed_ms": round((time.time() - started) * 1000, 1),
            "agent_ms": final.get("elapsed_ms", 0),
            "intent": final.get("intent"),
        })

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/api/config")
def update_config(body: ConfigIn):
    if body.yellow_line >= body.red_line:
        raise HTTPException(400, "黄色线必须低于红色线")
    CONFIG["red_line"] = body.red_line
    CONFIG["yellow_line"] = body.yellow_line
    if body.absence_warn_ratio is not None:
        CONFIG["policy"]["absence_warn_ratio"] = body.absence_warn_ratio
    if body.midterm_fail_trigger is not None:
        CONFIG["policy"]["midterm_fail_trigger"] = body.midterm_fail_trigger
    rebuild()
    o = ENGINE.overview()
    return {"ok": True, "config": CONFIG, "overview": o}


@app.get("/api/config")
def get_config():
    return CONFIG


@app.get("/api/llm/status")
def llm_status(probe: int = 0):
    """大模型健康状态，前端顶部黄条用。

    probe=1 时真发一次最小请求探活（几个 token），用于点「重试连接」后立刻
    确认恢复没有——不然 HEALTH 要等到下一次真实对话才会翻回正常。
    """
    if probe and llm.available():
        llm.chat([{"role": "user", "content": "ping"}], max_tokens=4, timeout=12)
    return llm.health()


@app.get("/api/interventions/{sid}")
def list_interventions(sid: str):
    return {"items": INTERVENTIONS.get(sid, [])}


@app.post("/api/interventions/{sid}")
def add_intervention(sid: str, body: InterventionIn):
    if sid not in {s["id"] for s in DATASET["students"]}:
        raise HTTPException(404, "学生不存在")
    COUNTER["n"] += 1
    item = {
        "id": COUNTER["n"],
        "title": body.title,
        "status": body.status,
        "note": body.note,
        "created_at": datetime.now().strftime("%m-%d %H:%M"),
    }
    INTERVENTIONS.setdefault(sid, []).insert(0, item)
    return {"ok": True, "item": item}


# ---------------------------------------------------------------------------
# 方案 C「对话即操作」：AI 只 propose，人点确认才 execute
# ---------------------------------------------------------------------------
class ActionExecIn(BaseModel):
    id: str
    type: str
    payload: dict = {}


class ActionUndoIn(BaseModel):
    id: str


def _action_export_letter(aid: str, payload: dict, profile: dict) -> dict:
    """导出文书：只排版，不落盘——真正的文件在点下载时由 /api/export 生成。"""
    sid = (payload.get("sid") or "").strip()
    if not sid:
        raise HTTPException(400, "缺少学生学号")
    kind = payload.get("letter_type") or "parent"
    s = ENGINE.get(sid)
    letter = _letter_of(sid, kind)
    return {
        "ok": True,
        "message": f"《{letter.get('title') or '学业文书'}》已按模板排好，点下载保存到本机。",
        "download_url": f"/api/export/letter/{sid}?type={kind}",
        "filename": f"{letter.get('title') or '学业文书'}_{datetime.now().strftime('%Y%m%d')}.docx",
        "target": s["name"],
    }


def _action_send_letter(aid: str, payload: dict, profile: dict) -> dict:
    """发送家长信：SMTP 配了就真发，没配就产出 .eml（收件人已填好）。"""
    from urllib.parse import quote

    sid = (payload.get("sid") or "").strip()
    if not sid:
        raise HTTPException(400, "缺少学生学号")
    letter = _letter_of(sid, "parent")
    s = ENGINE.get(sid)
    to_addr = (payload.get("to") or "").strip() or f"parent.{sid}@example.com"
    res = exporter.send_letter_email(letter, to_addr)
    if not res.get("ok"):
        raise HTTPException(502, f"发送失败：{res.get('error', '未知错误')}")
    if res.get("mode") == "smtp":
        return {
            "ok": True,
            "mode": "smtp",
            "message": f"已发送给 {s['name']} 的家长（{to_addr}）。",
            "undo_note": "邮件已经发出，无法从收件箱撤回；撤销只回退系统里的留痕。",
        }
    return {
        "ok": True,
        "mode": "eml",
        "message": f"当前未配置邮件服务器，已生成 {s['name']} 家长信的邮件文件（收件人已填好）。",
        "download_url": f"/api/export/send/{sid}?to={quote(to_addr)}",
        "filename": f"家长信_{s['name']}.eml",
        "undo_note": "邮件文件不会被真正发出，撤销等于作废这次操作。",
    }


def _action_record(aid: str, payload: dict, profile: dict) -> dict:
    """记入干预台账：这一条会打上 action_id，撤销时按它反查删除。"""
    sid = (payload.get("sid") or "").strip()
    if not sid:
        raise HTTPException(400, "缺少学生学号")
    if sid not in {x["id"] for x in DATASET["students"]}:
        raise HTTPException(404, "学生不存在")
    s = ENGINE.get(sid)
    COUNTER["n"] += 1
    item = {
        "id": COUNTER["n"],
        "title": payload.get("title") or "学业谈话",
        "status": payload.get("status") or "已完成",
        "note": payload.get("note") or "",
        "created_at": datetime.now().strftime("%m-%d %H:%M"),
        "action_id": aid,
    }
    INTERVENTIONS.setdefault(sid, []).insert(0, item)
    return {
        "ok": True,
        "message": f"已写入 {s['name']}（{s['class_name']}）的干预台账：{item['title']} · {item['status']}。",
        "ref": str(item["id"]),
    }


def _action_message(aid: str, payload: dict, profile: dict) -> dict:
    """给家长发一条沟通消息：走家校沟通同一条链路，家长端立刻能看到。"""
    sid = (payload.get("sid") or "").strip()
    text = (payload.get("text") or "").strip()
    if not sid:
        raise HTTPException(400, "缺少学生学号")
    if not text:
        raise HTTPException(400, "消息内容不能为空")
    if len(text) > 500:
        raise HTTPException(400, "单条消息不超过 500 字")
    s = ENGINE.get(sid)
    msg = MESSAGES.send("counselor", COUNSELOR_ACCOUNT, profile.get("name") or "辅导员",
                        "parent", sid, f"{s['name']} 家长", text, sid)
    return {
        "ok": True,
        "message": f"已发给 {s['name']} 的家长，家长端在「家校沟通」里能看到。",
        "ref": msg["id"],
    }


ACTION_HANDLERS = {
    "export_letter": _action_export_letter,
    "send_letter": _action_send_letter,
    "record_intervention": _action_record,
    "message_parent": _action_message,
}


@app.post("/api/actions/execute")
def actions_execute(body: ActionExecIn, request: Request):
    """第二段：用户点了「确认执行」才真正落地。同一个 id 只生效一次。"""
    p = request.state.profile
    role = p.get("role")
    if body.type not in actions_mod.WHITELIST:
        raise HTTPException(404, "未知的动作类型")
    if not actions_mod.allowed(role, body.type):
        raise HTTPException(403, "当前角色不能执行这个动作")
    prev = actions_mod.ACTION_STORE.begin(
        body.id, body.type, body.payload, actor=p.get("account") or "")
    if prev is not None:
        # 幂等命中：刷新页面再点、连点两下，都返回首次结果，不重复写入
        return prev
    try:
        result = ACTION_HANDLERS[body.type](body.id, body.payload, p)
    except HTTPException as exc:
        actions_mod.ACTION_STORE.fail(body.id, str(exc.detail))
        raise
    except Exception as exc:  # noqa: BLE001
        actions_mod.ACTION_STORE.fail(body.id, str(exc))
        raise HTTPException(500, f"执行失败：{exc}")
    return actions_mod.ACTION_STORE.finish(body.id, result)


@app.post("/api/actions/undo")
def actions_undo(body: ActionUndoIn, request: Request):
    """执行错了能退回来：删记录 / 撤回消息；文书与邮件只回退留痕。"""
    profile = request.state.profile
    role = profile.get("role")
    row = actions_mod.ACTION_STORE.get(body.id)
    if not row:
        raise HTTPException(404, "没有这个动作的执行记录")
    if not actions_mod.allowed(role, row.get("type") or ""):
        raise HTTPException(403, "当前角色不能撤销这个动作")
    if row.get("state") == "undone":
        return {"ok": True, "state": "undone", "message": "这个动作已经撤销过了。"}
    if row.get("state") != "done":
        raise HTTPException(400, "只有执行成功的动作才能撤销")

    atype = row.get("type")
    payload = row.get("payload") or {}
    note = ""
    if atype == "record_intervention":
        sid = payload.get("sid") or ""
        rows = INTERVENTIONS.get(sid) or []
        hit = next((i for i, it in enumerate(rows) if it.get("action_id") == body.id), None)
        if hit is None:
            note = "台账里已经没有这条记录。"
        else:
            rows.pop(hit)
            note = "已从干预台账删除这条记录。"
    elif atype == "message_parent":
        ref = (row.get("result") or {}).get("ref")
        gone = MESSAGES.recall(str(ref)) if ref else None
        note = "已撤回发给家长的那条消息。" if gone else "那条消息已经不在了。"
    else:
        note = (row.get("result") or {}).get("undo_note") or "这次操作只回退了系统留痕。"

    actions_mod.ACTION_STORE.mark_undone(body.id, note)
    return {"ok": True, "state": "undone", "message": note}


@app.get("/api/actions/{aid}")
def actions_get(aid: str):
    """卡片刷新后回填真实状态：页面重开也知道这张卡到底执行过没有。"""
    row = actions_mod.ACTION_STORE.get(aid)
    if not row:
        return {"id": aid, "state": "proposed"}
    return row


class _HashedAssets(StaticFiles):
    """带 hash 的前端资源目录。

    正常情况下直接命中文件。只有当浏览器还拿着上一版 index.html、
    来要一个已经被新部署替换掉的 assets/index-<旧hash>.js 时才会 404 ——
    这时不要回 {"detail":"Not Found"}（页面会白屏或直接把这段 JSON 显示出来），
    而是回一段几行的脚本让页面自己刷新拿最新入口。带次数上限，避免死循环。
    """

    _HEAL = (
        "(function(){try{var k='ag.reload';"
        "var n=+(sessionStorage.getItem(k)||0);"
        "if(n>=2){console.warn('[学业护航] 资源版本仍不一致，请手动刷新页面');return;}"
        "sessionStorage.setItem(k,String(n+1));"
        "console.warn('[学业护航] 前端资源已更新，正在自动刷新');"
        "location.replace(location.pathname+location.search);"
        "}catch(e){location.reload();}})();"
    )

    async def get_response(self, path, scope):
        try:
            return await super().get_response(path, scope)
        except StarletteHTTPException as exc:
            if exc.status_code != 404:
                raise
            return Response(
                self._HEAL,
                media_type="application/javascript",
                headers={"Cache-Control": "no-store"},
            )


app.mount("/static", StaticFiles(directory=LEGACY), name="static")

# Vite 构建产物：带 hash 的静态资源单独挂载，index.html 之外的深层路由交给下面的回退
if (DIST / "assets").exists():
    app.mount("/assets", _HashedAssets(directory=DIST / "assets"), name="assets")


@app.get("/{full_path:path}")
def spa_fallback(full_path: str):
    """Vue Router 用 history 模式，非 API 路径一律交回 index.html。"""
    if full_path.startswith("api/"):
        raise HTTPException(404, "Not Found")
    if (DIST / "index.html").exists():
        target = DIST / full_path
        if full_path and target.is_file():
            return FileResponse(target)
    return _entry_response()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", "8600")))
