/**
 * 方案 C · 对话即操作验收：
 * 1 回答末尾给出一张「待确认」的动作卡，AI 不直接执行；
 * 2 点「确认执行」才落地，卡片变「已完成」并可下载；
 * 3 点「撤销」把动作退回去（台账删记录 / 消息撤回）；
 * 4 学生端拿不到「发给家长」这类动作（越权入口不存在）；
 * 5 同一个 action id 重复提交只生效一次（幂等）。
 *
 * 前置：本地 127.0.0.1:8600 已启动，且是含方案 C 的构建。
 */
import puppeteer from "puppeteer-core";

const EXE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const BASE = "http://127.0.0.1:8600";
const OUT = "shots_round7";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ok = (label, cond, extra = "") =>
  console.log(`${cond ? "PASS" : "FAIL"} · ${label}${extra ? " —— " + extra : ""}`);

const browser = await puppeteer.launch({
  executablePath: EXE,
  headless: true,
  args: ["--disable-gpu", "--no-sandbox", "--proxy-server=direct://", "--proxy-bypass-list=*"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1320, height: 950 });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));

async function login(role, account, password, path) {
  const r = await fetch(`${BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ role, account, password }),
  });
  const j = await r.json();
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.evaluate((t) => {
    localStorage.clear();
    localStorage.setItem("ag.token", t);
  }, j.token);
  await page.goto(`${BASE}${path}`, { waitUntil: "networkidle2" });
  await sleep(2200);
  return j.token;
}

async function ask(text, wait = 9000) {
  const input = await page.$(".ch-draft input, .ch-draft textarea");
  await input.type(text);
  await page.keyboard.press("Enter");
  await sleep(wait);
}

async function lastCard() {
  return page.evaluate(() => {
    const cards = [...document.querySelectorAll(".act")];
    const c = cards[cards.length - 1];
    if (!c) return null;
    return {
      type: c.getAttribute("data-action-type"),
      id: c.getAttribute("data-action-id"),
      state: c.querySelector(".act-state")?.textContent?.trim() || "",
      label: c.querySelector(".act-label")?.textContent?.trim() || "",
      result: c.querySelector(".act-result")?.textContent?.trim() || "",
      hasConfirm: !!c.querySelector('[data-test="action-confirm"]'),
      hasUndo: !!c.querySelector('[data-test="action-undo"]'),
      hasDownload: !!c.querySelector('[data-test="action-download"]'),
      count: cards.length,
    };
  });
}

/* ---------------- 1. 辅导员：谈话要点 → 一张待确认卡片 ---------------- */
await login("counselor", "2024014589", "1111", "/counselor");
await ask("苏亦菲的谈话要点");

const proposed = await lastCard();
ok("回答末尾给出动作卡片", !!proposed, proposed ? proposed.label : "没找到 .act");
ok("动作类型是「记入台账」", proposed?.type === "record_intervention", proposed?.type || "");
ok("状态停在「待你确认」", proposed?.state === "待你确认", proposed?.state || "");
ok("未确认时没有执行结果", !proposed?.result, proposed?.result || "无结果，符合预期");
await page.screenshot({ path: `${OUT}/1-proposed.png` });

/* ---------------- 2. 点确认执行 → 已完成 ---------------- */
await page.click('[data-test="action-confirm"]');
await sleep(1800);
const done = await lastCard();
ok("确认后变「已完成」", done?.state === "已完成", done?.state || "");
ok("完成后出现撤销入口", !!done?.hasUndo);
ok("完成文案里有台账留痕", /干预台账|台账/.test(done?.result || ""), done?.result || "");
await page.screenshot({ path: `${OUT}/2-done.png` });

/* ---------------- 3. 撤销 → 已撤销 ---------------- */
await page.click('[data-test="action-undo"]');
await sleep(1500);
const undone = await lastCard();
ok("撤销后变「已撤销」", undone?.state === "已撤销", undone?.state || "");
ok("撤销文案说明反操作", /删除|撤回|回退|作废/.test(undone?.result || ""), undone?.result || "");
await page.screenshot({ path: `${OUT}/3-undone.png` });

/* ---------------- 4. 幂等：同一个 id 再提交一次，台账不重复 ---------------- */
const dup = await page.evaluate(async (aid) => {
  const token = localStorage.getItem("ag.token");
  const res = await fetch("/api/actions/execute", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      "X-Ag-Token": token,
    },
    body: JSON.stringify({ id: aid, type: "record_intervention", payload: { sid: "20240097" } }),
  });
  return res.json();
}, proposed.id);
ok("重复提交被判为回放", dup?.replayed === true, JSON.stringify(dup).slice(0, 80));

/* ---------------- 5. 红色学生：给家长发告知函 ---------------- */
await ask("苏亦菲的风险分为什么这么高");
const send = await lastCard();
ok("红色预警给的是「发家长信」", send?.type === "send_letter", send?.type || "");
await page.click('[data-test="action-confirm"]');
await sleep(2200);
const sent = await lastCard();
ok("发信后变「已完成」", sent?.state === "已完成", sent?.state || "");
ok("未配 SMTP 时给下载按钮", !!sent?.hasDownload);
await page.screenshot({ path: `${OUT}/4-send.png` });

/* ---------------- 6. 刷新页面：卡片状态还在（不会又变回待确认） ---------------- */
await page.reload({ waitUntil: "networkidle2" });
await sleep(2800);
const afterReload = await lastCard();
ok("刷新后卡片仍是已完成", afterReload?.state === "已完成", afterReload?.state || "");

/* ---------------- 7. 学生端：只能导出自己的文书 ---------------- */
await login("student", "20240023", "0000", "/student");
await ask("我的告知函写了什么");
const stu = await lastCard();
ok("学生端也有动作卡片", !!stu, stu?.type || "");
ok("学生端拿到的是导出，不是发信", stu?.type === "export_letter", stu?.type || "");
const leak = await page.evaluate(() =>
  [...document.querySelectorAll(".act")].map((c) => c.getAttribute("data-action-type")),
);
ok("学生端页面没有任何发信动作", !leak.includes("send_letter"), JSON.stringify(leak));
await page.screenshot({ path: `${OUT}/5-student.png` });

console.log("页面报错：", errors.length ? errors.slice(0, 3) : "无");
await browser.close();
