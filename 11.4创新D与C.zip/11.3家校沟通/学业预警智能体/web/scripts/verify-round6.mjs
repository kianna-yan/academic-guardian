/**
 * 方案 D · 证据链验收：
 * 1 每次工具调用都有「来源 · 表 · 命中条数 · 时刻」；
 * 2 前端渲染成时间线（默认展开、可收起）；
 * 3 引用按校规/数据/文书分组，默认片段、点击展开原文。
 */
import puppeteer from "puppeteer-core";

const EXE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const BASE = "http://127.0.0.1:8600";
const OUT = "shots_round6";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ok = (label, cond, extra = "") =>
  console.log(`${cond ? "PASS" : "FAIL"} · ${label}${extra ? " —— " + extra : ""}`);

const browser = await puppeteer.launch({
  executablePath: EXE,
  headless: true,
  args: ["--disable-gpu", "--no-sandbox", "--proxy-server=direct://", "--proxy-bypass-list=*"],
});
const page = await browser.newPage();
await page.setViewport({ width: 1320, height: 950 });
page.on("pageerror", (e) => console.log("PAGEERROR:", e.message));

const r = await fetch(`${BASE}/api/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ role: "student", account: "20240023", password: "0000" }),
});
const j = await r.json();
await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
await page.evaluate((t) => {
  localStorage.clear();
  localStorage.setItem("ag.token", t);
}, j.token);
await page.goto(`${BASE}/student`, { waitUntil: "networkidle2" });
await sleep(2500);

// 问一个同时命中校规与数据的题目
const input = await page.$(".ch-draft input, .ch-draft textarea");
await input.type("挂多少学分会被降级？");
await page.keyboard.press("Enter");
await sleep(9000);

const shape = await page.evaluate(() => {
  const chains = [...document.querySelectorAll(".chain")];
  const last = chains[chains.length - 1];
  const rows = last ? [...last.querySelectorAll(".chain-row")] : [];
  return {
    chainCount: chains.length,
    head: last?.querySelector(".chain-head")?.innerText.replace(/\s+/g, " ").trim() || "",
    steps: rows.map((r) => ({
      tool: r.querySelector(".cr-top b")?.textContent?.trim() || "",
      rows: r.querySelector(".cr-rows")?.textContent?.trim() || "",
      src: r.querySelector(".cr-src")?.textContent?.replace(/\s+/g, " ").trim() || "",
      args: r.querySelector(".cr-args")?.textContent?.trim() || "",
    })),
    groups: [...document.querySelectorAll(".cite-group")].map((g) => ({
      label: g.querySelector(".cg-head span")?.textContent?.trim() || "",
      n: g.querySelectorAll(".cite").length,
    })),
  };
});
console.log("证据链头部：", shape.head);
shape.steps.forEach((s) => console.log(`  · ${s.tool} | ${s.rows} | ${s.src}`));
console.log("引用分组：", JSON.stringify(shape.groups));

ok("出现证据链", shape.chainCount > 0, `共 ${shape.chainCount} 条`);
ok("每步都有来源与表名", shape.steps.length > 0 && shape.steps.every((s) => s.src.includes("·")));
ok("每步都有命中条数", shape.steps.every((s) => /命中 \d+/.test(s.rows)));
ok("头部汇总了步数与命中总数", /步 · 命中 \d+/.test(shape.head), shape.head);
ok("引用至少分出一组", shape.groups.length >= 1, JSON.stringify(shape.groups));

// 引用折叠 → 展开（挑一条确实被截断的，否则看不出折叠效果）
const target = await page.evaluate(() => {
  const cites = [...document.querySelectorAll(".cite")];
  const i = cites.findIndex((c) => (c.querySelector(".cite-text")?.innerText || "").includes("…"));
  return i >= 0 ? i : 0;
});
const before = await page.evaluate((i) => {
  const c = document.querySelectorAll(".cite")[i];
  return { len: c.querySelector(".cite-text").innerText.length, more: c.querySelector(".cite-more").innerText };
}, target);
await page.evaluate((i) => document.querySelectorAll(".cite")[i].click(), target);
await sleep(400);
const after = await page.evaluate((i) => {
  const c = document.querySelectorAll(".cite")[i];
  return {
    len: c.querySelector(".cite-text").innerText.length,
    more: c.querySelector(".cite-more").innerText,
    src: c.querySelector(".cite-src")?.innerText.trim() || "",
  };
}, target);
ok("引用默认折叠成片段", before.more === "看原文", `首屏 ${before.len} 字`);
ok("点击后展开原文", after.len > before.len && after.more === "收起", `${before.len} → ${after.len} 字`);
if (after.src) console.log("  展开后显示出处：", after.src);
await page.screenshot({ path: `${OUT}/1-chain-open.png` });

// 收起证据链
await page.click(".chain-head");
await sleep(400);
const collapsed = await page.evaluate(() => !document.querySelector(".chain-list"));
ok("证据链可收起", collapsed);

await browser.close();
console.log("\n完成，截图在 web/" + OUT + "/");
