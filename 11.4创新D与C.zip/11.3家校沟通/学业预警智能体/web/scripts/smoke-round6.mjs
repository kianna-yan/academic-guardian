import puppeteer from "puppeteer-core";
const EXE = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const BASE = "http://127.0.0.1:8600";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const browser = await puppeteer.launch({ executablePath: EXE, headless: true,
  args: ["--disable-gpu", "--no-sandbox", "--proxy-server=direct://", "--proxy-bypass-list=*"] });
const page = await browser.newPage();
await page.setViewport({ width: 1320, height: 900 });
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));

const ROLES = [
  ["student", "20240023", "0000", "/student", "我哪次作业没交"],
  ["parent", "20240063", "3333", "/parent", "孩子的风险分是多少"],
  ["counselor", "2024014589", "1111", "/counselor", "谁的风险最高"],
  ["admin", "1234567899", "2222", "/admin", "全校现在的预警分布"],
  ["teacher", "2024014501", "4444", "/teacher", "我课上的学生"],
];
for (const [role, acc, pwd, home, q] of ROLES) {
  const r = await fetch(`${BASE}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ role, account: acc, password: pwd }) });
  const j = await r.json();
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle2" });
  await page.evaluate((t) => { localStorage.clear(); localStorage.setItem("ag.token", t); }, j.token);
  await page.goto(`${BASE}${home}`, { waitUntil: "networkidle2" });
  await sleep(2200);
  const input = await page.$(".ch-draft input, .ch-draft textarea");
  if (!input) { console.log(`SKIP ${role} 没找到输入框`); continue; }
  await input.type(q);
  await page.keyboard.press("Enter");
  await sleep(8500);
  const st = await page.evaluate(() => {
    const chains = [...document.querySelectorAll(".chain")];
    const last = chains[chains.length - 1];
    return {
      steps: last ? last.querySelectorAll(".chain-row").length : 0,
      groups: [...document.querySelectorAll(".cite-group .cg-head span")].map((e) => e.textContent.trim()),
      replyLen: (document.querySelectorAll(".bubble, .msg")[0]?.innerText || "").length,
    };
  });
  console.log(`${role.padEnd(10)} 证据链 ${st.steps} 步 · 分组 ${JSON.stringify(st.groups)}`);
}
console.log("页面报错：", errors.length ? errors.slice(0, 3) : "无");
await browser.close();
