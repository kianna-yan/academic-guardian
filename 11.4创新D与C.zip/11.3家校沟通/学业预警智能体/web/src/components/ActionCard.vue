<script setup lang="ts">
import { computed } from "vue";
import { downloadDoc } from "@/api/client";
import type { ChatAction } from "@/types";

/**
 * 方案 C「对话即操作」的卡片：AI 只把要做的事摆出来，人点确认才执行。
 *
 * 一条动作走四个状态，卡片自己把当前状态写清楚：
 *   proposed（待确认）→ running（执行中）→ done（已完成，可撤销）
 *   出错时留在 error，但按钮还能再点一次（后端按 id 幂等，不会重复写入）。
 *
 * 为什么要有这张卡而不是让 AI 直接执行：发信、写信、发消息都是对外副作用，
 * 「AI 建议 → 人确认 → 系统留痕」这件事本身就是可交付性的一部分。
 */
const props = defineProps<{ action: ChatAction }>();
const emit = defineEmits<{ (e: "run"): void; (e: "undo"): void }>();

const a = computed(() => props.action);
const status = computed(() => a.value.status || "proposed");

const META: Record<string, { icon: string; name: string }> = {
  export_letter: { icon: "📄", name: "导出文书" },
  send_letter: { icon: "✉️", name: "发送家长信" },
  record_intervention: { icon: "📝", name: "记入干预台账" },
  message_parent: { icon: "💬", name: "给家长发消息" },
};

const meta = computed(() => META[a.value.type] || { icon: "⚡", name: "建议操作" });

const STATUS_TEXT: Record<string, string> = {
  proposed: "待你确认",
  running: "执行中…",
  done: "已完成",
  undone: "已撤销",
  error: "执行失败",
};

/** 卡片上给一眼能看懂的内容预览：发消息看正文，写台账看标题 */
const preview = computed(() => {
  const p = a.value.payload || {};
  if (a.value.type === "message_parent") return String(p.text || "");
  if (a.value.type === "record_intervention") {
    const title = String(p.title || "");
    const note = String(p.note || "");
    return note ? `${title} · ${note}` : title;
  }
  if (a.value.type === "export_letter") {
    return p.letter_type === "student" ? "学业预警告知函（Word）" : "家长告知函（Word）";
  }
  if (a.value.type === "send_letter") return `收件人：${p.to || "家长邮箱"}`;
  return "";
});
</script>

<template>
  <div class="act" :class="status" :data-action-id="a.id" :data-action-type="a.type">
    <div class="act-head">
      <span class="act-ico" aria-hidden="true">{{ meta.icon }}</span>
      <b class="act-kind">{{ meta.name }}</b>
      <span class="act-state">{{ STATUS_TEXT[status] }}</span>
    </div>

    <p class="act-label">{{ a.label }}</p>
    <p v-if="preview && status === 'proposed'" class="act-preview">{{ preview }}</p>
    <p v-if="a.hint && status === 'proposed'" class="act-hint">{{ a.hint }}</p>

    <p v-if="status === 'done' || status === 'undone'" class="act-result">
      <span class="act-tick">{{ status === "done" ? "✓" : "↺" }}</span>
      {{ a.result?.message || (status === "done" ? "已执行。" : "已撤销。") }}
      <em v-if="a.result?.replayed" class="act-replay">（这次是重复提交，未重复执行）</em>
    </p>
    <p v-if="a.error" class="act-err">{{ a.error }}</p>

    <div class="act-actions">
      <button
        v-if="status === 'proposed' || status === 'error'"
        type="button"
        class="act-btn primary"
        data-test="action-confirm"
        @click="emit('run')"
      >
        确认执行
      </button>
      <button
        v-if="status === 'running'"
        type="button"
        class="act-btn primary"
        disabled
      >
        <span class="act-spin"></span> 执行中…
      </button>
      <button
        v-if="status === 'done' && a.result?.download_url"
        type="button"
        class="act-btn"
        data-test="action-download"
        @click="downloadDoc(a.result!.download_url!)"
      >
        下载{{ a.result?.filename?.endsWith('.eml') ? '邮件' : '文件' }}
      </button>
      <button
        v-if="status === 'done'"
        type="button"
        class="act-btn ghost"
        data-test="action-undo"
        @click="emit('undo')"
      >
        撤销
      </button>
      <span v-if="status === 'proposed'" class="act-note">不点就不会执行</span>
    </div>
  </div>
</template>

<style scoped>
.act {
  margin-top: 10px;
  border: 1px solid #f0d8b4;
  border-left: 3px solid var(--brand);
  background: linear-gradient(180deg, #fffaf2 0%, #fffdf9 100%);
  border-radius: 4px 10px 10px 4px;
  padding: 9px 12px 10px;
}
.act.done {
  border-left-color: var(--green);
  border-color: #d5ead9;
  background: linear-gradient(180deg, #f7fdf9 0%, #fcfefd 100%);
}
.act.undone {
  border-left-color: #b09b85;
  border-color: #ece2d4;
  background: #fbf8f3;
}
.act.error {
  border-left-color: var(--red);
  border-color: #f6d5d5;
  background: #fffafa;
}
.act-head {
  display: flex;
  align-items: center;
  gap: 6px;
}
.act-ico {
  font-size: 12px;
  line-height: 1;
}
.act-kind {
  font-size: 11.5px;
  font-weight: 600;
  color: #8a6d16;
  letter-spacing: 0.2px;
}
.act-state {
  font-size: 10.5px;
  color: var(--brand);
  background: var(--brand-soft);
  border-radius: 999px;
  padding: 0 7px;
  line-height: 16px;
}
.act.done .act-state {
  color: var(--green);
  background: var(--green-soft);
}
.act.undone .act-state {
  color: var(--muted);
  background: #f3ece1;
}
.act.error .act-state {
  color: var(--red);
  background: var(--red-soft);
}
.act-label {
  margin: 5px 0 0;
  font-size: 13px;
  font-weight: 600;
  color: var(--text);
  line-height: 1.5;
}
.act-preview {
  margin: 4px 0 0;
  font-size: 12px;
  color: var(--text-2);
  line-height: 1.65;
  white-space: pre-wrap;
  background: #fff;
  border: 1px dashed #efdfc6;
  border-radius: 6px;
  padding: 6px 8px;
}
.act-hint {
  margin: 4px 0 0;
  font-size: 11px;
  color: #a58c72;
  line-height: 1.55;
}
.act-result {
  margin: 6px 0 0;
  font-size: 12px;
  color: #1f6b45;
  line-height: 1.6;
}
.act.undone .act-result {
  color: var(--muted);
}
.act-tick {
  margin-right: 3px;
}
.act-replay {
  font-style: normal;
  color: #a58c72;
  font-size: 10.5px;
}
.act-err {
  margin: 5px 0 0;
  font-size: 11.5px;
  color: var(--red);
}
.act-actions {
  display: flex;
  align-items: center;
  gap: 7px;
  margin-top: 8px;
  flex-wrap: wrap;
}
.act-btn {
  font-size: 11.5px;
  border-radius: 7px;
  border: 1px solid var(--line-strong);
  background: #fff;
  color: var(--text-2);
  padding: 4px 11px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  transition: background 0.15s, border-color 0.15s;
}
.act-btn:hover:not(:disabled) {
  background: #fdf6ea;
}
.act-btn.primary {
  background: var(--brand);
  border-color: var(--brand);
  color: #fff;
  font-weight: 600;
}
.act-btn.primary:hover:not(:disabled) {
  background: #c26a05;
}
.act-btn.ghost {
  color: var(--muted);
  border-style: dashed;
}
.act-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}
.act-note {
  font-size: 10.5px;
  color: #b09b85;
}
.act-spin {
  width: 9px;
  height: 9px;
  border: 1.5px solid rgba(255, 255, 255, 0.45);
  border-top-color: #fff;
  border-radius: 50%;
  animation: act-spin 0.7s linear infinite;
}
@keyframes act-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
