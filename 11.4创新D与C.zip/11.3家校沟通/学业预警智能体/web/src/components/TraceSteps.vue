<script setup lang="ts">
import { computed, ref } from "vue";
import type { ChatTrace } from "@/types";

/**
 * 证据链：把「工具调用」从一串胶囊变成可追溯的时间线。
 *
 * 每一步回答四个问题：查的哪张表（source · table）、命中几条（rows）、
 * 什么时候查的（ts）、花了多久（ms）。回答里的每个数字都能顺这条链找回出处，
 * 所以默认展开——这条链本身就是给人看的证据，藏起来等于没有。
 */
const props = defineProps<{ trace: ChatTrace[]; pending?: boolean; elapsed?: number }>();

/** 工具名 → 人话。Agent 的"思考过程"必须让人看得懂，否则轨迹没有意义。 */
const LABEL: Record<string, string> = {
  risk_score: "查风险评分",
  interventions: "取干预建议",
  retrieve_policy: "检索校规库",
  search_policy: "检索校规库",
  roster: "查风险名单",
  list_roster: "查风险名单",
  campus_overview: "统计全校数据",
  get_overview: "统计全校数据",
  grade_trend: "拉成绩走势",
  counselor_brief: "生成谈话要点",
  record_intervention: "写入干预台账",
  export_file: "排版文书",
  send_letter: "发送家长信",
  send_parent_letter: "发送家长信",
  daily_report: "聚合预警日报",
  teacher_view: "取课堂数据",
  get_student: "查学生档案",
  get_attendance: "查考勤明细",
  get_homework: "查作业明细",
  get_risk: "查风险评分",
  llm_polish: "大模型润色",
};

const open = ref(true);

const steps = computed(() =>
  (props.trace || []).map((t) => {
    const ev = t.evidence;
    const args = Object.entries(t.args || {})
      .filter(([, v]) => v !== null && v !== undefined && v !== "")
      .map(([k, v]) => `${k}=${String(v).slice(0, 24)}`)
      .join(" ");
    return {
      label: LABEL[t.tool] || t.tool,
      tool: t.tool,
      ms: t.ms,
      args,
      source: ev?.source || "运行时",
      table: ev?.table || "—",
      rows: ev?.rows ?? 0,
      unit: ev?.unit || "条",
      ts: ev?.ts || "",
      detail: ev?.detail || "",
      hasEvidence: !!ev,
    };
  }),
);

/** 头部汇总：几步、共命中多少条、总共多久 */
const totalRows = computed(() => steps.value.reduce((s, x) => s + (x.rows || 0), 0));
const totalMs = computed(() => {
  const sum = steps.value.reduce((s, x) => s + (x.ms || 0), 0);
  return sum >= 1 ? Math.round(sum) : Math.round(props.elapsed || 0);
});
/** 单位一致时用它（名学生 / 条条款）；混着来就统一说「项」 */
const unit = computed(() => {
  const us = new Set(steps.value.map((s) => s.unit));
  return us.size === 1 ? [...us][0] : "项";
});
</script>

<template>
  <div v-if="steps.length || pending" class="chain" :class="{ folding: !open }">
    <button type="button" class="chain-head" @click="open = !open">
      <span class="ch-icon" aria-hidden="true">🔗</span>
      <b>证据链</b>
      <span class="ch-meta">
        {{ steps.length }} 步 · 命中 {{ totalRows }} {{ unit }}
        <em v-if="totalMs">· {{ totalMs }} ms</em>
      </span>
      <span v-if="pending" class="ch-live">进行中</span>
      <span class="ch-toggle">{{ open ? "收起" : "展开" }}</span>
    </button>

    <ol v-if="open" class="chain-list">
      <li v-for="(s, i) in steps" :key="`${s.tool}-${i}`" class="chain-row">
        <span class="cr-dot" aria-hidden="true"></span>
        <div class="cr-body">
          <div class="cr-top">
            <b>{{ s.label }}</b>
            <span class="cr-rows">命中 {{ s.rows }} {{ s.unit }}</span>
            <em v-if="s.ms >= 1" class="cr-ms">{{ Math.round(s.ms) }} ms</em>
          </div>
          <div class="cr-src">
            {{ s.source }} · {{ s.table }}<template v-if="s.ts"> · {{ s.ts }}</template>
          </div>
          <div v-if="s.args" class="cr-args">参数：{{ s.args }}</div>
          <div v-if="s.detail" class="cr-detail">条款编号：{{ s.detail }}</div>
        </div>
      </li>
      <li v-if="pending" class="chain-row running">
        <span class="cr-dot" aria-hidden="true"></span>
        <div class="cr-body"><div class="cr-top"><b>正在取数…</b></div></div>
      </li>
    </ol>
  </div>
</template>

<style scoped>
.chain {
  margin-top: 14px;
  border: 1px solid #ecdfca;
  border-radius: 10px;
  background: #fdfaf4;
  overflow: hidden;
}
.chain-head {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 7px 11px;
  border: 0;
  background: transparent;
  cursor: pointer;
  text-align: left;
  font-size: 12px;
  color: #7a6450;
}
.chain-head:hover {
  background: #f9f1e4;
}
.ch-icon {
  font-size: 11px;
  opacity: 0.75;
}
.chain-head b {
  font-weight: 600;
  color: #5d4a37;
  font-size: 12px;
}
.ch-meta {
  flex: 1;
  min-width: 0;
  font-size: 11px;
  color: #a08872;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ch-meta em {
  font-style: normal;
  font-family: ui-monospace, monospace;
}
.ch-live {
  flex: none;
  font-size: 10.5px;
  color: var(--brand);
  background: var(--brand-soft);
  border-radius: 999px;
  padding: 1px 7px;
}
.ch-toggle {
  flex: none;
  font-size: 10.5px;
  color: #b09b85;
  border-left: 1px solid #ecdfca;
  padding-left: 8px;
}

/* 时间线：左侧竖线 + 圆点，最后一项自动收线 */
.chain-list {
  margin: 0;
  padding: 2px 11px 10px 12px;
  list-style: none;
  border-top: 1px dashed #eee0c9;
}
.chain-row {
  position: relative;
  display: flex;
  gap: 10px;
  padding: 7px 0 3px 0;
}
.chain-row:not(:last-child)::before {
  content: "";
  position: absolute;
  left: 3px;
  top: 16px;
  bottom: -6px;
  width: 1px;
  background: #e7d8c0;
}
.cr-dot {
  flex: none;
  width: 7px;
  height: 7px;
  margin-top: 6px;
  border-radius: 50%;
  background: #c9a97f;
  box-shadow: 0 0 0 3px #fdfaf4;
  z-index: 1;
}
.chain-row.running .cr-dot {
  background: var(--brand);
  animation: pulse 1s ease-in-out infinite;
}
.cr-body {
  flex: 1;
  min-width: 0;
}
.cr-top {
  display: flex;
  align-items: baseline;
  gap: 8px;
  flex-wrap: wrap;
}
.cr-top b {
  font-size: 12px;
  font-weight: 600;
  color: #4a3a2a;
}
.cr-rows {
  font-size: 10.5px;
  color: #8a6d16;
  background: #fdf1de;
  border-radius: 4px;
  padding: 0 5px;
  line-height: 15px;
}
.cr-ms {
  font-style: normal;
  font-size: 10px;
  color: #b09b85;
  font-family: ui-monospace, monospace;
}
.cr-src {
  margin-top: 2px;
  font-size: 10.5px;
  color: #96826c;
  line-height: 1.5;
  word-break: break-all;
}
.cr-args,
.cr-detail {
  margin-top: 1px;
  font-size: 10px;
  color: #ab9884;
  line-height: 1.5;
  word-break: break-all;
}
@keyframes pulse {
  0%,
  100% {
    opacity: 0.35;
  }
  50% {
    opacity: 1;
  }
}
</style>
