<script setup lang="ts">
import { computed, ref } from "vue";
import type { Citation } from "@/types";

/**
 * 引用来源：按「校规依据 / 数据依据 / 文书依据」分组，默认只给一句片段，
 * 点一下才展开原文。
 *
 * 为什么分组：原来所有引用平铺成一串，校规条款和分数明细混在一起，
 * 看不出「这句话是制度规定的，还是从学生数据算出来的」——而这恰恰是
 * 学业预警最需要区分的一件事（学生要的是依据，老师要的是数据）。
 * 为什么折叠：一条校规动辄几百字，全展开会把回答挤到首屏之外。
 */
const props = withDefaults(
  defineProps<{ citations: Citation[]; maxChars?: number; title?: string }>(),
  { maxChars: 160, title: "引用来源" },
);

const GROUPS = [
  { key: "policy", label: "校规依据" },
  { key: "data", label: "数据依据" },
  { key: "letter", label: "文书依据" },
] as const;

const opened = ref<Record<string, boolean>>({});
const toggle = (k: string) => {
  opened.value[k] = !opened.value[k];
};

function snippet(text: string, max: number) {
  const t = (text || "").replace(/\s+/g, " ").trim();
  return t.length > max ? `${t.slice(0, max)}…` : t;
}

const groups = computed(() => {
  const list = props.citations || [];
  return GROUPS.map((g) => ({
    ...g,
    items: list.filter((c) => (c.kind || "policy") === g.key),
  })).filter((g) => g.items.length);
});
const total = computed(() => (props.citations || []).length);
</script>

<template>
  <div v-if="total" class="cites">
    <div class="cites-title">
      {{ title }}<span class="cites-count">{{ total }} 条</span>
    </div>

    <div v-for="g in groups" :key="g.key" class="cite-group">
      <div class="cg-head">
        <i class="cg-bar" :class="g.key"></i>
        <span>{{ g.label }}</span>
        <em>{{ g.items.length }}</em>
      </div>

      <div
        v-for="(c, i) in g.items"
        :key="`${g.key}-${i}`"
        class="cite"
        :class="{ open: opened[`${g.key}-${i}`] }"
        role="button"
        tabindex="0"
        @click="toggle(`${g.key}-${i}`)"
        @keydown.enter="toggle(`${g.key}-${i}`)"
      >
        <div class="cite-top">
          <b>{{ c.citation }}</b>
          <span class="cite-more">{{ opened[`${g.key}-${i}`] ? "收起" : "看原文" }}</span>
        </div>
        <p class="cite-text">
          {{ opened[`${g.key}-${i}`] ? c.text : snippet(c.text, maxChars) }}
        </p>
        <div v-if="opened[`${g.key}-${i}`] && c.source" class="cite-src">
          出处：{{ c.source }}<template v-if="c.file"> · {{ c.file }}</template>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.cites {
  margin-top: 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.cites-title {
  font-size: 12px;
  color: var(--muted);
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 6px;
}
.cites-count {
  font-size: 10.5px;
  color: #a08872;
  background: #f7f0e5;
  border-radius: 999px;
  padding: 0 6px;
  line-height: 15px;
}
.cite-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.cg-head {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 10.5px;
  letter-spacing: 0.04em;
  color: #96826c;
}
.cg-head em {
  font-style: normal;
  color: #b09b85;
}
.cg-bar {
  width: 3px;
  height: 11px;
  border-radius: 2px;
  background: #c9a97f;
}
.cg-bar.policy {
  background: #9a6b3f;
}
.cg-bar.data {
  background: #2f7d63;
}
.cg-bar.letter {
  background: #b45309;
}
.cite {
  border-left: 2px solid #ddcbb3;
  padding: 3px 0 3px 9px;
  font-size: 11.5px;
  color: var(--text-2);
  cursor: pointer;
  border-radius: 0 6px 6px 0;
  transition: background 0.12s;
}
.cite:hover {
  background: #fbf7ef;
}
.cite.open {
  background: #fdfaf4;
}
.cite-top {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 10px;
}
.cite-top b {
  font-weight: 500;
  color: var(--text);
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.cite-more {
  flex: none;
  font-size: 10px;
  color: #b09b85;
  text-decoration: underline;
  text-underline-offset: 2px;
}
.cite-text {
  margin: 2px 0 0;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
}
.cite-src {
  margin-top: 4px;
  font-size: 10px;
  color: #ab9884;
  font-family: ui-monospace, monospace;
}
</style>
